(function(){
  // Kleine pseudo-random generator zodat een seed altijd dezelfde mix oplevert
  function mulberry32(a) {
    return function() {
      var t = a += 0x6D2B79F5;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
  }
  // Zet een tekst (bijv. seed) om naar een getal zodat mulberry32 ermee kan mixen
  function seedFromString(s) {
    let h = 1779033703 ^ s.length;
    for (let i=0; i<s.length; i++) {
      h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
      h = (h << 13) | (h >>> 19);
    }
    return (h>>>0);
  }
  // Kleine helper zodat er niet steeds document.querySelector hoeft worden getypt
  const qs = s => document.querySelector(s);
  // Pak direct alle belangrijke elementen uit de UI
  const boardEl = qs('#board');
  const movesEl = qs('#moves');
  const timeEl = qs('#time');
  const statusEl = qs('#status');
  const seedInput = qs('#seedInput');
  const themeSelect = qs('#themeSelect');
  const sizeSelect = qs('#sizeSelect');
  const newGameBtn = qs('#newGame');
  const resetBtn = qs('#reset');
  const applySeedBtn = qs('#applySeed');
  const copyLinkBtn = qs('#copyLink');
  const hintBtn = qs('#hint');
  const soundToggleBtn = qs('#soundToggle');
  const exportAnalyticsBtn = qs('#exportAnalytics');
  const clearAnalyticsBtn = qs('#clearAnalytics');
  const coachEl = qs('#coach');
  const coachTitleEl = coachEl ? coachEl.querySelector('.coach-title') : null;
  const coachBodyEl = coachEl ? coachEl.querySelector('.coach-body') : null;
  const menuToggleBtn = qs('#menuToggle');
  const closeSettingsBtn = qs('#closeSettings');
  const settingsPanel = qs('#settingsPanel');
  const introScreen = qs('#introScreen');
  const introStartBtn = qs('#introStart');
  const winScreen = qs('#winScreen');
  const nextChallengeBtn = qs('#nextChallenge');
  const winCloseBtn = qs('#winClose');
  const winMovesEl = qs('#winMoves');
  const winTimeEl = qs('#winTime');
  const winHintsEl = qs('#winHints');
  const winSummaryEl = winScreen ? winScreen.querySelector('.screen-text') : null;
  const winXpEl = qs('#winXp');
  const showCoachBtn = qs('#showCoach');
  const appEl = qs('.app');
  const boardWrapper = boardEl ? boardEl.parentElement : null;
  const progressSummaryEl = qs('#progressSummary');
  const profileLevelEl = qs('#profileLevel');
  const xpBarFillEl = qs('#xpBarFill');
  const xpTextEl = qs('#xpText');
  const bestSummaryEl = qs('#bestSummary');
  const dailyStreakEl = qs('#dailyStreak');
  const lastDailyEl = qs('#lastDaily');
  const dailyChallengeBtn = qs('#dailyChallenge');
  const liveRegion = qs('#live');
  const tutorialCard = qs('#tutorialCard');
  const tutorialTitleEl = tutorialCard ? tutorialCard.querySelector('#tutorialTitle') : null;
  const tutorialTextEl = tutorialCard ? tutorialCard.querySelector('#tutorialText') : null;
  const tutorialNextBtn = tutorialCard ? tutorialCard.querySelector('#tutorialNext') : null;
  const newPlayerGuide = qs('#newPlayerGuide');
  const guideDismissBtn = newPlayerGuide ? newPlayerGuide.querySelector('[data-action="guide-dismiss"]') : null;
  const showGuideBtn = qs('#showGuide');

  // Variabelen die de huidige spelstatus en instellingen vasthouden
  let SIZE = 4; // dynamische bordgrootte
  let GOAL = makeGoal(SIZE); // 0 = empty
  let startState = GOAL.slice();
  let state = GOAL.slice();
  let moves = 0;
  let timer = null;
  let seconds = 0;
  let started = false;
  let rng = Math.random;
  let moveFX = null; // { val:number, from:'left'|'right'|'top'|'bottom' }
  let prevEmptyIndex = null; // voor hint-heuristiek (reversals vermijden)
  const SOUND_PREF_KEY = 'mindshift-sound';
  const audioState = { ctx: null, master: null, noiseBuffer: null };
  let soundEnabled = true;
  let lastCoachTimeout = null;
  const ANALYTICS_STORAGE_KEY = 'mindshift.analytics.sessions';
  let currentSessionId = null;
  let sessionEvents = [];
  const SESSION_LIMIT = 40;
  let sessionsCache = [];
  let sessionStartTime = Date.now();
  let gameStartTime = Date.now();
  let currentGameId = uuid();
  let hintCount = 0;
  let settingsOpen = false;
  let coachVisible = true;
  let introActive = false;
  let countdownActive = false;
  const countdownTimers = [];
  const CAMPAIGN_PATH = [3,4,5];
  let statusBeforePause = 'Aan het spelen';
  const PROFILE_STORAGE_KEY = 'mindshift.profile';
  let profile = null;
  let currentGameMode = 'standard';
  let dailyChallengeInfo = null;
  let lastWinProgression = null;
  // Alles wat de tutorial nodig heeft om te weten in welke stap je zit
  const tutorialState = {
    active: false,
    stage: 0,
    pointerEl: null,
    highlightTileIndex: null,
    pointerLabel: '',
    pointerDirection: 'up',
    hintedButton: false,
    awaitingMove: false,
    pendingAction: null,
    dimMaskEl: false,
    mode: 'onboarding',
    stepsCompleted: 0,
    maxSteps: 3,
    lastMoveTile: null
  };
  // State-variabelen die vroeger voor automatische hints dienden (nu uitgeschakeld)
  let autoHintQueue = [];
  let autoHintTimer = null;
  let autoHintActive = false;
  let autoHintExecuting = false;

  // Zet de coachtekst en laat 'm eventueel tijdelijk oplichten
  function setCoachMessage(title, body, highlight=false, duration=4800){
    if(!coachEl) return;
    if(coachTitleEl) coachTitleEl.textContent = title;
    if(coachBodyEl) coachBodyEl.textContent = body;
    coachEl.classList.toggle('active', !!highlight);
    if(lastCoachTimeout){
      clearTimeout(lastCoachTimeout);
      lastCoachTimeout = null;
    }
    if(highlight){
      lastCoachTimeout = setTimeout(()=>{
        coachEl.classList.remove('active');
        lastCoachTimeout = null;
      }, duration);
      if(coachEl.classList.contains('collapsed')){
        setCoachVisible(true, false);
      }
    }
  }

  // Update de statusbalk of de live region, fijn voor screenreaders
  function updateStatus(text){
    if(statusEl){
      statusEl.textContent = text;
    } else if(liveRegion){
      liveRegion.textContent = text;
    }
  }

  // Laat kort een statusmelding zien en zet daarna de oude tekst terug
  function flashStatus(text, duration=1600){
    if(statusEl){
      const previous = statusEl.textContent;
      statusEl.textContent = text;
      setTimeout(()=> updateStatus(previous), duration);
      return;
    }
    if(!liveRegion) return;
    const previous = liveRegion.textContent;
    liveRegion.textContent = text;
    setTimeout(()=>{
      if(liveRegion.textContent === text){
        liveRegion.textContent = previous;
      }
    }, duration);
  }

  // Check of het winscherm nu in beeld is
  function isWinVisible(){
    return !!(winScreen && !winScreen.hasAttribute('hidden'));
  }

  // Check of het intro-scherm open staat
  function isIntroVisible(){
    return !!(introScreen && !introScreen.hasAttribute('hidden'));
  }

  // Kijkt of het spel tijdelijk op slot zit (aftellen, win, intro)
  function isInteractionLocked(){
    return countdownActive || settingsOpen || isIntroVisible() || isWinVisible();
  }

  // Zet een klasse op de body zodat scrollen stopt wanneer er een overlay is
  function updateBodyLock(){
    const shouldLock = isInteractionLocked();
    document.body.classList.toggle('modal-open', shouldLock);
  }

  // Klapt de coach open of dicht en bewaart die keuze
  function setCoachVisible(flag, log=true){
    coachVisible = !!flag;
    if(coachEl) coachEl.classList.toggle('collapsed', !coachVisible);
    if(showCoachBtn){
      showCoachBtn.setAttribute('aria-expanded', coachVisible ? 'true' : 'false');
      showCoachBtn.textContent = coachVisible ? 'Verberg coach' : 'Toon coach';
    }
    if(log) appendEvent('coach_toggle', { visible: coachVisible });
  }

  // Zet de uitlegkaart voor nieuwe spelers klaar en luistert naar de 'ik snap het'-knop
  function initNewPlayerGuide(){
    if(!newPlayerGuide) return;
    if(profile && profile.guideDismissed){
      newPlayerGuide.open = false;
      newPlayerGuide.classList.add('guide-collapsed');
    }
    newPlayerGuide.addEventListener('toggle', ()=>{
      newPlayerGuide.classList.toggle('guide-collapsed', !newPlayerGuide.open);
    });
    if(guideDismissBtn){
      guideDismissBtn.addEventListener('click', ()=>{
        newPlayerGuide.open = false;
        if(profile){
          profile.guideDismissed = true;
          saveProfile();
        }
        appendEvent('guide_dismiss', { source: 'button' });
        flashStatus('Uitleg verborgen', 1400);
      });
    }
  }

  // Maakt een vers profiel met level 1, 0 XP en geen streak
  function defaultProfile(){
    const recordSizes = [3,4,5,6,7,8];
    const records = {};
    recordSizes.forEach(size => {
      records[size] = { time: null, moves: null, completed: 0 };
    });
    return {
      version: 1,
      totalXp: 0,
      totalWins: 0,
      totalGames: 0,
      totalHints: 0,
      totalDailyCompletions: 0,
      records,
      guideDismissed: false,
      daily: {
        streak: 0,
        lastCompletedDate: null,
        lastSeed: null
      },
      lastLevelNotification: null,
      tutorial: {
        completed: false,
        stage: 0
      }
    };
  }

  // Zet oudere opgeslagen data om naar het nieuwe profielmodel
  function migrateProfile(raw){
    const base = defaultProfile();
    if(!raw || typeof raw !== 'object') return base;
    const merged = { ...base, ...raw };
    merged.version = 1;
    merged.records = { ...base.records, ...(raw.records || {}) };
    merged.daily = { ...base.daily, ...(raw.daily || {}) };
    merged.tutorial = { ...base.tutorial, ...(raw.tutorial || {}) };
    if(typeof merged.guideDismissed !== 'boolean') merged.guideDismissed = false;
    if(typeof merged.totalXp !== 'number' || merged.totalXp < 0) merged.totalXp = 0;
    if(typeof merged.totalWins !== 'number' || merged.totalWins < 0) merged.totalWins = 0;
    if(typeof merged.totalGames !== 'number' || merged.totalGames < 0) merged.totalGames = 0;
    if(typeof merged.totalHints !== 'number' || merged.totalHints < 0) merged.totalHints = 0;
    if(typeof merged.totalDailyCompletions !== 'number' || merged.totalDailyCompletions < 0) merged.totalDailyCompletions = 0;
    return merged;
  }

  // Zorgt dat er voor iedere bordgrootte een stats-object bestaat
  function ensureRecord(profileObj, size){
    if(!profileObj) return;
    if(!profileObj.records) profileObj.records = {};
    if(!profileObj.records[size]){
      profileObj.records[size] = { time: null, moves: null, completed: 0 };
    }
  }

  // Leest het profiel uit localStorage of bouwt er een als het mist
  function loadProfile(){
    try {
      const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
      if(!raw) return defaultProfile();
      const parsed = JSON.parse(raw);
      return migrateProfile(parsed);
    } catch {
      return defaultProfile();
    }
  }

  // Bewaart het profiel veilig in localStorage
  function saveProfile(){
    if(!profile) return;
    try { localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile)); } catch {}
  }

  // Berekent hoeveel XP je nodig hebt voor het volgende level
  function xpForLevel(level){
    return Math.round(120 + (level - 1) * 45);
  }

  // Splitst totale XP uit naar level en voortgang naar het volgende
  function deriveLevelProgress(totalXp){
    let level = 1;
    let xpPool = Math.max(0, Math.floor(totalXp || 0));
    let cost = xpForLevel(level);
    while(xpPool >= cost){
      xpPool -= cost;
      level++;
      cost = xpForLevel(level);
      if(level > 250){
        break; // guard rail
      }
    }
    return {
      level,
      xpIntoLevel: xpPool,
      xpToNext: cost
    };
  }

  // Geeft een datum terug als YYYY-MM-DD in lokale tijd
  function getLocalIsoDate(date = new Date()){
    const tzOffset = date.getTimezoneOffset();
    const local = new Date(date.getTime() - tzOffset * 60000);
    return local.toISOString().slice(0,10);
  }

  // Legt uit of de daily challenge van vandaag al gedaan is
  function describeDailyStatus(isoDate){
    if(!isoDate) return 'Nog niet gestart';
    const today = getLocalIsoDate();
    if(isoDate === today) return 'Vandaag voltooid';
    const yesterday = getLocalIsoDate(new Date(Date.now() - 86400000));
    if(isoDate === yesterday) return 'Gisteren voltooid';
    const [y,m,d] = isoDate.split('-').map(Number);
    const date = new Date(y, (m || 1) - 1, d || 1);
    return date.toLocaleDateString(navigator.language || 'nl-NL', { day: 'numeric', month: 'short' });
  }

  // Ververs de UI met level, XP-balk, streak en beste tijden
  function updateProfileUI(){
    if(!profile) return;
    const { level, xpIntoLevel, xpToNext } = deriveLevelProgress(profile.totalXp);
    if(profileLevelEl) profileLevelEl.textContent = String(level);
    if(xpBarFillEl){
      const pct = xpToNext > 0 ? Math.min(100, Math.round((xpIntoLevel / xpToNext) * 100)) : 0;
      xpBarFillEl.style.width = `${pct}%`;
      if(xpBarFillEl.parentElement){
        xpBarFillEl.parentElement.setAttribute('aria-valuenow', String(Math.min(xpToNext, xpIntoLevel)));
      }
    }
    if(xpTextEl){
      xpTextEl.textContent = `${xpIntoLevel} / ${xpToNext} XP`;
    }
    const daily = profile.daily || {};
    const streak = daily.streak || 0;
    if(dailyStreakEl){
      dailyStreakEl.textContent = String(streak);
    }
    if(lastDailyEl){
      lastDailyEl.textContent = describeDailyStatus(daily.lastCompletedDate || null);
    }
    if(bestSummaryEl){
      const recordSizes = Object.keys(profile.records || {})
        .map(Number)
        .filter(size => Number.isFinite(size) && profile.records[size]);
      let bestSize = null;
      let bestRecord = null;
      recordSizes.forEach(size => {
        const rec = profile.records[size];
        if(!rec || !Number.isFinite(rec.time)) return;
        if(bestRecord === null || rec.time < bestRecord.time){
          bestRecord = rec;
          bestSize = size;
        }
      });
      if(bestRecord && Number.isFinite(bestRecord.time)){
        const timeText = fmtTime(bestRecord.time);
        const moveText = Number.isFinite(bestRecord.moves) ? `${bestRecord.moves} zetten` : null;
        const sizeLabel = bestSize ? `${bestSize}×${bestSize}` : '';
        const prefix = sizeLabel ? `Beste tijd (${sizeLabel})` : 'Beste tijd';
        bestSummaryEl.textContent = moveText
          ? `${prefix}: ${timeText} (${moveText})`
          : `${prefix}: ${timeText}`;
      } else {
        bestSummaryEl.textContent = 'Beste tijd: --:--';
      }
    }
    if(progressSummaryEl){
      if(profile.totalWins <= 0){
        progressSummaryEl.textContent = 'Start een spel om XP te verdienen en je streak te verhogen.';
      } else {
        const streak = daily.streak || 0;
        const winWord = profile.totalWins === 1 ? 'overwinning' : 'overwinningen';
        const streakPart = streak > 0 ? ` · streak ${streak} ${streak === 1 ? 'dag' : 'dagen'}` : '';
        progressSummaryEl.textContent = `Level ${level} · ${profile.totalXp} XP · ${profile.totalWins} ${winWord}${streakPart}`;
      }
    }
    updateDailyUI();
  }

  // Bepaalt op basis van de datum welke daily challenge hoort
  function computeDailyChallenge(date = new Date()){
    const isoDate = getLocalIsoDate(date);
    const hash = seedFromString(isoDate);
    const size = CAMPAIGN_PATH[hash % CAMPAIGN_PATH.length] || 4;
    const themes = ['light','dark','matrix','shopify','ios'];
    const theme = themes[hash % themes.length];
    return {
      isoDate,
      seed: `daily-${isoDate}`,
      size,
      theme
    };
  }

  // Update de tekst rond de daily challenge knop
  function updateDailyUI(){
    if(!dailyChallengeBtn) return;
    const info = computeDailyChallenge();
    const daily = profile ? profile.daily || {} : {};
    const streak = daily.streak || 0;
    const completedToday = daily.lastCompletedDate === info.isoDate;
    dailyChallengeBtn.textContent = `Dagelijkse uitdaging (${info.size}×${info.size})`;
    dailyChallengeBtn.dataset.seed = info.seed;
    dailyChallengeBtn.dataset.size = String(info.size);
    dailyChallengeBtn.dataset.date = info.isoDate;
    dailyChallengeBtn.title = completedToday ? 'Je hebt de dagelijkse uitdaging al voltooid. Speel opnieuw voor skills of probeer morgen weer voor streak.' : 'Voltooi de dagelijkse uitdaging voor extra XP en streak.';
    dailyChallengeBtn.classList.toggle('completed', completedToday);
    if(dailyStreakEl) dailyStreakEl.textContent = String(streak);
    if(lastDailyEl) lastDailyEl.textContent = describeDailyStatus(daily.lastCompletedDate || null);
  }

  // Bepaalt of de tutorial automatisch moet starten voor deze speler
  function shouldStartTutorial(){
    if(!profile || !profile.tutorial) return false;
    if(!tutorialCard || !tutorialNextBtn || !tutorialTitleEl || !tutorialTextEl) return false;
    if(profile.tutorial.completed) return false;
    if(currentGameMode !== 'standard') return false;
    return true;
  }

  // Start de onboarding tutorial en zet alle stappen klaar
  function beginTutorial(options={}){
    const {
      mode = 'onboarding',
      maxSteps = mode === 'guide' ? 3 : 3,
      force = false
    } = options;

    if(mode === 'onboarding' && !force && !shouldStartTutorial()) return;

    tutorialState.mode = mode;
    tutorialState.maxSteps = Math.max(1, Number(maxSteps) || 3);
    tutorialState.stepsCompleted = 0;
    tutorialState.stage = 0;
    tutorialState.active = true;
    tutorialState.awaitingMove = mode === 'guide' ? false : true;
    tutorialState.hintedButton = false;
    tutorialState.pendingAction = null;
    tutorialState.lastMoveTile = null;
    clearTutorialPointer();
    removeTutorialMask();
    hideTutorialCard();

    if(mode === 'onboarding'){
      if(profile && profile.tutorial){
        profile.tutorial.stage = 0;
        saveProfile();
      }
      tutorialState.awaitingMove = true;
      requestAnimationFrame(()=>{
        showTutorialFirstMoveCue();
      });
      return;
    }

    appendEvent('guide_start', {
      steps: tutorialState.maxSteps,
      board: state.slice()
    });

    showTutorialCard(
      'Snelle uitleg',
      'We lopen samen de eerste drie zetten door. Klik op "Start" en volg de markeringen op het bord.',
      'Start',
      ()=>{
        hideTutorialCard();
        tutorialState.awaitingMove = true;
        showTutorialFirstMoveCue();
      }
    );
    if(liveRegion){
      liveRegion.textContent = 'Interactieve uitleg gestart. Druk op Start om de aanwijzingen te volgen.';
    }
  }

  // Laat de eerste hint zien zodat je weet welke tegel je moet schuiven
  function showTutorialFirstMoveCue(){
    if(!tutorialState.active || !boardEl) return;
    const suggestion = computeHintSuggestion();
    const index = suggestion ? suggestion.primaryIndex : null;
    if(index === null || index === undefined){
      tutorialState.highlightTileIndex = null;
      clearTutorialPointer();
      if(tutorialState.mode === 'guide'){
        tutorialState.awaitingMove = false;
        requestAnimationFrame(()=>{
          showTutorialCard(
            'Geen zetten beschikbaar',
            'Start een nieuw spel of maak ruimte op het bord, dan kunnen we de stappen laten zien.',
            'Terug',
            ()=>{
              hideTutorialCard();
              finishTutorial();
            }
          );
        });
      }
      return;
    }
    tutorialState.highlightTileIndex = index;
    const emptyIndex = state.indexOf(0);
    const direction = deriveDirection(index, emptyIndex);
    const tile = boardEl.querySelector(`.tile[data-index="${index}"]`);
    const tileValue = tile ? tile.textContent || state[index] : state[index];
    const dirText = tutorialDirectionText(direction);
    if(tutorialState.mode === 'guide'){
      const stepNumber = tutorialState.stepsCompleted + 1;
      const total = tutorialState.maxSteps;
      const label = `Stap ${stepNumber}/${total}: tik op tegel ${tileValue}. Hij schuift ${dirText} het lege vak in.`;
      drawTutorialPointer(label, direction);
      if(liveRegion){
        liveRegion.textContent = label;
      }
    } else {
      const label = `Begin hier: tik op tegel ${tileValue}. Hij schuift ${dirText} en start het spel.`;
      drawTutorialPointer(label, direction);
    }
    updateTutorialMask(tile);
  }

  // Opent de volledige interactieve uitleg opnieuw
  function startInteractiveGuide(){
    if(isInteractionLocked()){
      flashStatus('Sluit eerst schermen voordat je de uitleg start.', 1600);
      return;
    }
    let solved = true;
    for(let i=0;i<GOAL.length;i++){
      if(state[i] !== GOAL[i]){ solved = false; break; }
    }
    appendEvent('guide_request', {
      moves,
      solved,
      board: state.slice()
    });
    if(isWinVisible()) hideWinScreen('guide');
    if(settingsOpen) closeSettings('auto');
    if(isIntroVisible()) hideIntroScreen('guide');

    if(solved){
      newGame('guide_demo', { skipCountdown: true });
    }

    if(newPlayerGuide){
      newPlayerGuide.open = true;
      newPlayerGuide.classList.remove('guide-collapsed');
    }
    if(profile){
      profile.guideDismissed = false;
      saveProfile();
    }
    flashStatus('Interactieve uitleg gestart', 1400);
    beginTutorial({ mode: 'guide', maxSteps: 3, force: true });
  }

  // Tekent een pijltje plus label bij een tegel of knop tijdens de tutorial
  function drawTutorialPointer(label, direction='up'){
    if(!boardEl || tutorialState.highlightTileIndex === null) return;
    const tile = boardEl.querySelector(`.tile[data-index="${tutorialState.highlightTileIndex}"]`);
    if(!tile) return;
    ensureTutorialMask();
    if(!tutorialState.pointerEl){
      const el = document.createElement('div');
      el.className = 'tutorial-pointer';
      const line = document.createElement('span');
      line.className = 'tutorial-pointer-line';
      const text = document.createElement('span');
      text.className = 'tutorial-pointer-text';
      el.appendChild(line);
      el.appendChild(text);
      tutorialState.pointerEl = el;
    }
    tutorialState.pointerEl.querySelector('.tutorial-pointer-text').textContent = label;
    tutorialState.pointerLabel = label;
    tutorialState.pointerDirection = direction;
    boardEl.appendChild(tutorialState.pointerEl);
    tile.classList.add('tile-tutorial');
    positionPointer(direction);
  }

  // Maakt een dimlaag zodat alleen het relevante deel oplicht
  function ensureTutorialMask(){
    if(!boardEl || tutorialState.dimMaskEl) return;
    tutorialState.dimMaskEl = true;
  }

  // Past de dimlaag aan zodat de juiste tegel zichtbaar blijft
  function updateTutorialMask(targetTile){
    if(!boardEl) return;
    ensureTutorialMask();
    const tiles = boardEl.querySelectorAll('.tile');
    tiles.forEach(tile => {
      if(tile === targetTile){
        tile.classList.add('tile-tutorial-target');
        tile.classList.remove('tile-dimmed');
      } else {
        tile.classList.add('tile-dimmed');
        tile.classList.remove('tile-tutorial-target');
      }
    });
  }

  // Haalt de dimlaag weg zodra het niet meer nodig is
  function removeTutorialMask(){
    if(!boardEl) return;
    boardEl.querySelectorAll('.tile').forEach(tile => {
      tile.classList.remove('tile-dimmed', 'tile-tutorial-target');
    });
    tutorialState.dimMaskEl = false;
  }

  // Berekent vanuit welke kant een tegel richting het lege vak schuift
  function deriveDirection(tileIndex, emptyIndex){
    const tilePos = indexToRC(tileIndex);
    const emptyPos = indexToRC(emptyIndex);
    if(emptyPos.r < tilePos.r) return 'up';
    if(emptyPos.r > tilePos.r) return 'down';
    if(emptyPos.c < tilePos.c) return 'left';
    if(emptyPos.c > tilePos.c) return 'right';
    return 'up';
  }

  // Plaatst het tutorial pijltje rondom de tegel die we uitleggen
  function positionPointer(direction = tutorialState.pointerDirection){
    if(!boardEl || tutorialState.highlightTileIndex === null) return;
    if(!tutorialState.pointerEl){
      if(!tutorialState.pointerLabel) return;
      drawTutorialPointer(tutorialState.pointerLabel, direction);
      return;
    }
    const tile = boardEl.querySelector(`.tile[data-index="${tutorialState.highlightTileIndex}"]`);
    if(!tile){
      clearTutorialPointer();
      return;
    }
    updateTutorialMask(tile);
    const boardRect = boardEl.getBoundingClientRect();
    const tileRect = tile.getBoundingClientRect();
    const pointer = tutorialState.pointerEl;
    if(pointer.parentNode !== boardEl){
      boardEl.appendChild(pointer);
    }
    const pointerLength = Math.min(Math.max(tileRect.width * 0.7, 64), 160);
    pointer.style.setProperty('--pointer-length', `${Math.round(pointerLength)}px`);
    pointer.style.left = `${tileRect.left - boardRect.left + tileRect.width / 2}px`;
    pointer.style.top = `${tileRect.top - boardRect.top + tileRect.height / 2}px`;
    pointer.dataset.dir = direction;
    pointer.dataset.active = '1';
  }

  // Verwijdert het pijltje en reset de pointer-state
  function clearTutorialPointer(){
    if(tutorialState.pointerEl && tutorialState.pointerEl.parentNode){
      tutorialState.pointerEl.parentNode.removeChild(tutorialState.pointerEl);
    }
    if(boardEl){
      boardEl.querySelectorAll('.tile-tutorial').forEach(node => node.classList.remove('tile-tutorial'));
    }
    tutorialState.pointerEl = null;
    tutorialState.highlightTileIndex = null;
    tutorialState.pointerLabel = '';
    removeTutorialMask();
  }

  // Laat de hintknop even oplichten wanneer de tutorial dat vraagt
  function highlightHintButton(flag){
    if(!hintBtn) return;
    hintBtn.classList.toggle('tutorial-focus', !!flag);
    if(flag && !tutorialState.hintedButton){
      tutorialState.hintedButton = true;
    }
  }

  // Toont een kaartje met uitlegtekst en een Verder-knop
  function showTutorialCard(title, body, buttonLabel='Verder', onNext=null){
    if(!tutorialCard) return;
    if(tutorialTitleEl) tutorialTitleEl.textContent = title;
    if(tutorialTextEl) tutorialTextEl.textContent = body;
    if(tutorialNextBtn) tutorialNextBtn.textContent = buttonLabel;
    tutorialState.pendingAction = typeof onNext === 'function' ? onNext : null;
    tutorialCard.hidden = false;
    tutorialCard.setAttribute('aria-hidden', 'false');
    tutorialCard.setAttribute('aria-live', 'assertive');
    if(tutorialNextBtn){
      requestAnimationFrame(()=>{
        try { tutorialNextBtn.focus({ preventScroll: true }); } catch { tutorialNextBtn.focus(); }
      });
    }
  }

  // Laat het afsluitende tutorialkaartje met compliment zien
  function showFinalTutorialCard(){
    highlightHintButton(false);
    removeTutorialMask();
    showTutorialCard(
      'Pro-tip',
      'Kom je vast te zitten? Gebruik de hint-knop of de pijltjestoetsen (WASD). Werk steeds één rij of kolom volledig af voordat je verder gaat.',
      'Aan de slag',
      ()=>{
        hideTutorialCard();
        if(profile && profile.tutorial){
          profile.tutorial.stage = 2;
          saveProfile();
        }
        finishTutorial();
      }
    );
  }

  // Verbergt het tutorialkaartje en haalt de listener weg
  function hideTutorialCard(){
    if(!tutorialCard) return;
    tutorialCard.hidden = true;
    tutorialCard.setAttribute('aria-hidden', 'true');
    tutorialCard.removeAttribute('aria-live');
    tutorialState.pendingAction = null;
  }

  // Reageert op de Verder-knop en triggert de volgende stap
  function handleTutorialCardNext(){
    if(tutorialState.pendingAction){
      const fn = tutorialState.pendingAction;
      tutorialState.pendingAction = null;
      fn();
    } else {
      hideTutorialCard();
    }
  }

  // Markeer dat de tutorial afgerond is en sla dat op
  function finishTutorial(){
    const mode = tutorialState.mode;
    tutorialState.active = false;
    tutorialState.stage = 3;
    tutorialState.awaitingMove = false;
    tutorialState.stepsCompleted = 0;
    tutorialState.lastMoveTile = null;
    hideTutorialCard();
    clearTutorialPointer();
    highlightHintButton(false);
    removeTutorialMask();
    if(mode === 'onboarding' && profile && profile.tutorial){
      profile.tutorial.completed = true;
      profile.tutorial.stage = 3;
      saveProfile();
    }
    tutorialState.mode = 'onboarding';
  }

  // Na elke zet kijkt dit of de tutorial een stap verder kan
  function handleTutorialAfterMove(){
    if(!tutorialState.active) return;
    if(tutorialState.mode === 'guide'){
      tutorialState.stepsCompleted = Math.min(tutorialState.maxSteps, tutorialState.stepsCompleted + 1);
      tutorialState.awaitingMove = false;
      const movedTile = tutorialState.lastMoveTile;
      appendEvent('guide_step', {
        step: tutorialState.stepsCompleted,
        target: movedTile,
        board: state.slice()
      });
      clearTutorialPointer();
      removeTutorialMask();
      if(tutorialState.stepsCompleted >= tutorialState.maxSteps){
        tutorialState.stage = 1;
        requestAnimationFrame(()=>{
          showTutorialCard(
            'Lekker bezig!',
            'Zo krijg je snel grip op de puzzel. Herhaal het patroon: eerst de bovenste rij, daarna de linkerkolom.',
            'Verder spelen',
            ()=>{
              hideTutorialCard();
              appendEvent('guide_complete', {
                steps: tutorialState.stepsCompleted,
                board: state.slice()
              });
              finishTutorial();
            }
          );
        });
      } else {
        tutorialState.stage = 0;
        tutorialState.awaitingMove = true;
        requestAnimationFrame(()=>{
          showTutorialFirstMoveCue();
        });
      }
      return;
    }
    if(tutorialState.stage === 0){
      tutorialState.stage = 0.5;
      tutorialState.awaitingMove = false;
      clearTutorialPointer();
      showTutorialCard(
        'Goed bezig!',
        'Doel: schuif de tegels naar oplopende volgorde (1 → 15). Werk rij voor rij: begin linksboven en houd de lege tegel uiteindelijk rechts onder.',
        'Volgende',
        ()=>{
          hideTutorialCard();
          tutorialState.stage = 1;
          tutorialState.awaitingMove = true;
          highlightHintButton(true);
          if(profile && profile.tutorial){
            profile.tutorial.stage = 1;
            saveProfile();
          }
        }
      );
      return;
    }
    if(tutorialState.stage === 1 && (moves >= 4 || hintCount > 0)){
      tutorialState.stage = 1.5;
      showFinalTutorialCard();
    }
  }

  // Houdt bij dat er een hint is gebruikt tijdens de tutorial
  function handleTutorialHintUsed(){
    if(!tutorialState.active) return;
    if(tutorialState.mode === 'guide') return;
    if(tutorialState.stage === 1){
      tutorialState.stage = 1.5;
      showFinalTutorialCard();
    }
  }

  // Logt dat een nieuw spel gestart is voor analytics en profiel
  function recordGameStart(mode='standard'){
    if(!profile) return;
    profile.totalGames = (profile.totalGames || 0) + 1;
    if(mode === 'daily' && dailyChallengeInfo){
      profile.daily = profile.daily || {};
      profile.daily.lastSeed = dailyChallengeInfo.seed;
    }
    saveProfile();
    updateProfileUI();
    if(mode === 'daily'){
      const daily = profile.daily || {};
      const streak = daily.streak || 0;
      const streakText = streak > 0 ? `Streak ${streak} ${streak === 1 ? 'dag' : 'dagen'} actief.` : 'Start je streak en pak de bonus.';
      setCoachMessage('Dagelijkse boost', `${streakText} Voltooi deze run voor +60 XP extra.`, true, 5200);
    }
  }

  // Registreert een hintmoment in de analytics
  function recordHintUsage(){
    if(!profile) return;
    profile.totalHints = (profile.totalHints || 0) + 1;
    saveProfile();
  }

  // Berekent hoeveel XP je verdient voor deze run
  function computeXpReward(){
    const base = SIZE * 40;
    const parMoves = SIZE <= 3 ? 42 : SIZE === 4 ? 140 : 240;
    const parTime = SIZE <= 3 ? 60 : SIZE === 4 ? 150 : 260;
    const speedBonus = Math.max(0, Math.round((parTime - seconds) / 12));
    const efficiencyBonus = Math.max(0, Math.round((parMoves - moves) / 4));
    const hintPenalty = hintCount * 18;
    const modeBonus = currentGameMode === 'daily' ? 60 : 0;
    const reward = base + speedBonus + efficiencyBonus + modeBonus - hintPenalty;
    return Math.max(20, reward);
  }

  // Werkt streak en daily data bij na een overwinning
  function updateDailyProgress(){
    if(!profile) return;
    const info = dailyChallengeInfo || computeDailyChallenge();
    const today = info.isoDate || getLocalIsoDate();
    const daily = profile.daily || {};
    const last = daily.lastCompletedDate;
    profile.daily = daily;
    if(last === today){
      profile.daily.lastSeed = info.seed;
      return;
    }
    const yesterday = getLocalIsoDate(new Date(Date.now() - 86400000));
    if(last === yesterday){
      profile.daily.streak = (profile.daily.streak || 0) + 1;
    } else {
      profile.daily.streak = 1;
    }
    profile.daily.lastCompletedDate = today;
    profile.daily.lastSeed = info.seed;
    profile.totalDailyCompletions = (profile.totalDailyCompletions || 0) + 1;
  }

  // Doet alle level/streak updates zodra je wint
  function handleWinProgression(){
    if(!profile) return null;
    ensureRecord(profile, SIZE);
    const record = profile.records[SIZE];
    profile.totalWins = (profile.totalWins || 0) + 1;
    record.completed = (record.completed || 0) + 1;
    if(!Number.isFinite(record.time) || seconds < record.time){
      record.time = seconds;
    }
    if(!Number.isFinite(record.moves) || moves < record.moves){
      record.moves = moves;
    }
    const xpGain = computeXpReward();
    const before = deriveLevelProgress(profile.totalXp);
    profile.totalXp = Math.max(0, Math.floor((profile.totalXp || 0) + xpGain));
    const after = deriveLevelProgress(profile.totalXp);
    if(currentGameMode === 'daily'){
      updateDailyProgress();
    }
    saveProfile();
    updateProfileUI();
    return {
      xpGain,
      leveledUp: after.level > before.level,
      level: after.level,
      previousLevel: before.level
    };
  }

  // Start direct de daily challenge met de juiste instellingen
  function startDailyChallenge(){
    if(isInteractionLocked()) return;
    const info = computeDailyChallenge();
    dailyChallengeInfo = info;
    if(sizeSelect && sizeSelect.value !== String(info.size)){
      sizeSelect.value = String(info.size);
    }
    setSize(info.size);
    if(seedInput){
      seedInput.value = info.seed;
    }
    applySeed(info.seed);
    if(themeSelect && themeSelect.value !== info.theme){
      themeSelect.value = info.theme;
    }
    setTheme(info.theme);
    updateDailyUI();
    appendEvent('daily_prepare', {
      isoDate: info.isoDate,
      seed: info.seed,
      size: info.size,
      theme: info.theme
    });
    newGame('daily_challenge', { skipCountdown: false, mode: 'daily' });
  }

  // Laat een duidelijke coach-tekst zien over badges of streaks
  function announceWinAchievements(badge, progression){
    if(!badge) return;
    const xpPart = progression ? ` +${progression.xpGain} XP` : '';
    const daily = profile ? profile.daily || {} : {};
    const streak = daily.streak || 0;
    const dailySnippet = currentGameMode === 'daily' && streak > 0
      ? ` Streak staat nu op ${streak} ${streak === 1 ? 'dag' : 'dagen'}.`
      : '';
    if(progression && progression.leveledUp){
      setCoachMessage(`Level ${progression.level}!`, `${badge.summary}${xpPart}.${dailySnippet}`, true, 7600);
      return;
    }
    setCoachMessage(`Badge: ${badge.title}`, `${badge.summary}${xpPart}.${dailySnippet}`, true, 6400);
  }

  // Opent het instellingenpaneel en voegt de juiste listeners toe
  function openSettings(source='button'){
    if(!settingsPanel || settingsOpen) return;
    settingsPanel.hidden = false;
    settingsOpen = true;
    if(menuToggleBtn) menuToggleBtn.setAttribute('aria-expanded', 'true');
    statusBeforePause = statusEl ? statusEl.textContent : 'Aan het spelen';
    updateStatus('Gepauzeerd');
    updateBodyLock();
    appendEvent('settings_open', { source });
    requestAnimationFrame(()=>{
      const focusable = settingsPanel.querySelector('select, input, button');
      if(focusable && typeof focusable.focus === 'function'){
        try { focusable.focus({ preventScroll: true }); } catch { focusable.focus(); }
      }
    });
  }

  // Sluit het instellingenpaneel en ruimt alles netjes op
  function closeSettings(reason='manual'){
    if(!settingsPanel || !settingsOpen) return;
    settingsPanel.hidden = true;
    settingsOpen = false;
    if(menuToggleBtn) menuToggleBtn.setAttribute('aria-expanded', 'false');
    updateStatus(statusBeforePause);
    updateBodyLock();
    appendEvent('settings_close', { reason });
    if(reason !== 'auto' && menuToggleBtn && typeof menuToggleBtn.focus === 'function'){
      try { menuToggleBtn.focus({ preventScroll: true }); } catch { menuToggleBtn.focus(); }
    }
  }

  // Wisselt tussen open en dicht voor het instellingenpaneel
  function toggleSettings(source='button'){
    if(settingsOpen){
      closeSettings('toggle');
    } else {
      openSettings(source);
    }
  }

  // Stopt de aftel-animatie en wist alle timers
  function clearCountdown(){
    while(countdownTimers.length){
      const id = countdownTimers.pop();
      clearTimeout(id);
    }
    const overlay = appEl ? appEl.querySelector('.countdown') : null;
    if(overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
    countdownActive = false;
    updateBodyLock();
  }

  // Speelt een aftelmoment af voordat een nieuw spel begint
  function startCountdown(onComplete){
    if(typeof onComplete === 'function') onComplete();
  }

  // Bepaalt welke bordgrootte de volgende campagne-stap is
  function nextCampaignSize(current=SIZE){
    const idx = CAMPAIGN_PATH.indexOf(current);
    if(idx === -1) return CAMPAIGN_PATH[0];
    return CAMPAIGN_PATH[(idx + 1) % CAMPAIGN_PATH.length];
  }

  // Maakt een confetti-explosie voor het winscherm
  function spawnConfettiBurst(){
    if(!boardWrapper) return;
    const pieces = 28;
    const fragment = document.createDocumentFragment();
    for(let i=0;i<pieces;i++){
      const piece = document.createElement('span');
      piece.className = 'confetti-piece';
      piece.style.setProperty('--confetti-hue', String(Math.floor(Math.random()*360)));
      piece.style.setProperty('--confetti-x', `${(Math.random()*240 - 120).toFixed(0)}px`);
      piece.style.setProperty('--confetti-rotate', `${(Math.random()*720 - 360).toFixed(0)}deg`);
      piece.style.animationDelay = (Math.random()*0.2).toFixed(2) + 's';
      fragment.appendChild(piece);
      piece.addEventListener('animationend', ()=>{
        if(piece.parentNode) piece.parentNode.removeChild(piece);
      }, { once: true });
      setTimeout(()=>{
        if(piece.parentNode) piece.parentNode.removeChild(piece);
      }, 1600);
    }
    boardWrapper.appendChild(fragment);
  }

  // Geeft een tegel een korte bounce zodat een hint opvalt
  function bounceTile(index){
    if(!boardEl) return;
    const tile = boardEl.querySelector(`.tile[data-index="${index}"]`);
    if(!tile) return;
    tile.classList.remove('tile-nudge');
    // force reflow
    void tile.offsetWidth;
    tile.classList.add('tile-nudge');
    setTimeout(()=> tile.classList.remove('tile-nudge'), 360);
  }

  // Berekent welke badge-tekst je verdient na winst
  function computeBadge(){
    const parMoves = SIZE <= 3 ? 42 : SIZE === 4 ? 140 : 240;
    const parTime = SIZE <= 3 ? 60 : SIZE === 4 ? 150 : 260;
    const speed = seconds <= parTime;
    const efficient = moves <= parMoves;
    const clean = hintCount === 0;
    if(speed && efficient && clean){
      return {
        title: 'Grandmaster',
        summary: 'Perfect run zonder hints én supersnel. Legendestatus!'
      };
    }
    if(speed && clean){
      return {
        title: 'Speedrunner',
        summary: 'In recordtijd én zonder hulp. Klaar voor de volgende klasse.'
      };
    }
    if(clean){
      return {
        title: 'Strategist',
        summary: 'Geen hints gebruikt – je oplossingsvermogen groeit zichtbaar.'
      };
    }
    if(hintCount >= Math.max(1, Math.ceil(SIZE/2))){
      return {
        title: 'Leerling',
        summary: 'Je gebruikte de coach slim. Volgende ronde: probeer minder hints!'
      };
    }
    return {
      title: 'Volhouder',
      summary: 'Doorzetten loont. Verscherp je route en verbeter je tijd.'
    };
  }

  // Toont het winscherm met statistieken en beloning
  function showWinScreen(){
    if(!winScreen) return;
    if(winMovesEl) winMovesEl.textContent = String(moves);
    if(winTimeEl) winTimeEl.textContent = fmtTime(seconds);
    if(winHintsEl) winHintsEl.textContent = String(hintCount);
    const badge = computeBadge();
    if(winSummaryEl) winSummaryEl.textContent = `${badge.title}: ${badge.summary}`;
    if(winXpEl){
      if(lastWinProgression){
        const xpText = `+${lastWinProgression.xpGain} XP` + (lastWinProgression.leveledUp ? ` • Level ${lastWinProgression.level}` : '');
        winXpEl.textContent = xpText;
        winXpEl.dataset.levelUp = lastWinProgression.leveledUp ? '1' : '0';
      } else {
        winXpEl.textContent = '';
        winXpEl.removeAttribute('data-level-up');
      }
    }
    if(nextChallengeBtn){
      const nextSize = nextCampaignSize();
      nextChallengeBtn.textContent = `Volgende uitdaging (${nextSize}×${nextSize})`;
    }
    winScreen.removeAttribute('hidden');
    updateBodyLock();
    appendEvent('win_screen_open', {
      moves,
      seconds,
      hints: hintCount,
      badge: badge.title,
      nextSize: nextCampaignSize()
    });
  }

  // Verbergt het winscherm en geeft de bediening terug
  function hideWinScreen(reason='manual'){
    if(!winScreen || winScreen.hasAttribute('hidden')) return;
    winScreen.setAttribute('hidden','');
    updateBodyLock();
    appendEvent('win_screen_close', { reason });
  }

  // Laat het intro-scherm zien wanneer je binnenkomt
  function showIntroScreen(){
    if(!introScreen) return;
    introScreen.removeAttribute('hidden');
    introActive = true;
    updateStatus('Klaar voor start');
    updateBodyLock();
    appendEvent('intro_show', {});
    if(introStartBtn && typeof introStartBtn.focus === 'function'){
      requestAnimationFrame(()=>{
        try { introStartBtn.focus({ preventScroll: true }); } catch { introStartBtn.focus(); }
      });
    }
  }

  // Sluit het intro-scherm en onthoud waarom
  function hideIntroScreen(reason='start'){
    if(!introScreen || introScreen.hasAttribute('hidden')) return;
    introScreen.setAttribute('hidden','');
    introActive = false;
    updateBodyLock();
    appendEvent('intro_dismiss', { reason });
  }

  const plural = (n, singular, pluralForm)=> n === 1 ? singular : pluralForm;
  const ordinals = ['eerste','tweede','derde','vierde','vijfde','zesde','zevende','achtste'];

  // Geeft woorden zoals 'eerste' of 'tweede' terug
  function ordinalWord(n){
    return ordinals[n-1] || `${n}e`;
  }

  // Maakt een simpele unieke id voor events
  function uuid(){
    if(window.crypto && crypto.randomUUID) return crypto.randomUUID();
    const template = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
    return template.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  // Leest oude sessies uit localStorage voor analytics
  function loadSessions(){
    try {
      const raw = localStorage.getItem(ANALYTICS_STORAGE_KEY);
      if(!raw) return [];
      const parsed = JSON.parse(raw);
      if(Array.isArray(parsed)) return parsed;
    } catch {}
    return [];
  }

  // Slaat de sessies weer op in localStorage
  function saveSessions(sessions){
    try { localStorage.setItem(ANALYTICS_STORAGE_KEY, JSON.stringify(sessions)); } catch {}
  }

  sessionsCache = loadSessions();
  setCoachVisible(true, false);
  if(menuToggleBtn) menuToggleBtn.setAttribute('aria-expanded', 'false');
  profile = loadProfile();
  updateProfileUI();
  saveProfile();
  initNewPlayerGuide();

  // Voeg een event toe aan de huidige sessie-log
  function appendEvent(type, payload={}){
    if(!currentSessionId) return;
    const now = Date.now();
    const event = {
      type,
      sessionId: currentSessionId,
      ts: now,
      sessionElapsedMs: now - sessionStartTime,
      gameId: currentGameId,
      gameElapsedMs: now - gameStartTime,
      moves,
      hints: hintCount,
      size: SIZE,
      theme: document.body.getAttribute('data-theme') || 'light',
      seed: seedInput ? (seedInput.value || '').trim() || null : null,
      payload
    };
    if(profile){
      const levelInfo = deriveLevelProgress(profile.totalXp);
      const daily = profile.daily || {};
      event.playerLevel = levelInfo.level;
      event.playerXp = profile.totalXp;
      event.playerStreak = daily.streak || 0;
      event.playerWins = profile.totalWins || 0;
    }
    sessionEvents.push(event);
    const session = sessionsCache.find(s => s.id === currentSessionId);
    if(session){
      session.events = sessionEvents;
      session.lastEventTs = now;
    }
    saveSessions(sessionsCache);
  }

  // Start een nieuwe analytics-sessie en pakt een verse id
  function startAnalyticsSession(){
    sessionStartTime = Date.now();
    currentSessionId = uuid();
    currentGameId = uuid();
    gameStartTime = sessionStartTime;
    hintCount = 0;
    const session = {
      id: currentSessionId,
      startedAt: sessionStartTime,
      userAgent: navigator.userAgent || 'unknown',
      events: []
    };
    sessionsCache.push(session);
    if(sessionsCache.length > SESSION_LIMIT) sessionsCache = sessionsCache.slice(-SESSION_LIMIT);
    sessionEvents = session.events;
    saveSessions(sessionsCache);
    appendEvent('session_start', {
      size: SIZE,
      theme: document.body.getAttribute('data-theme') || 'light',
      seed: seedInput ? (seedInput.value || '').trim() || null : null
    });
  }

  // Zet alle sessies om naar JSON en downloadt dat
  function exportAnalyticsData(){
    const data = {
      exportedAt: Date.now(),
      sessions: sessionsCache,
      profile
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g,'-');
    a.download = `mindshift-analytics-${timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(()=> URL.revokeObjectURL(url), 1000);
  }

  // Wist alle opgeslagen sessies
  function clearAnalyticsData(){
    const snapshot = {
      moves,
      hints: hintCount,
      board: state.slice(),
      size: SIZE
    };
    sessionsCache = [];
    sessionEvents = [];
    currentSessionId = null;
    try { localStorage.removeItem(ANALYTICS_STORAGE_KEY); } catch {}
    startAnalyticsSession();
    appendEvent('analytics_clear', snapshot);
    setCoachMessage('Coach', 'Analyticsdata gewist. Nieuwe sessie gestart.', true, 3200);
  }

  // Zet de coachtekst terug naar de standaard uitleg
  function resetCoach(){
    setCoachMessage('Coach', 'Klik op "Hint" voor een eenvoudige uitleg per stap.');
  }

  // Maakt een leesbare beschrijving van een richting (met pijltje)
  function describeDirection(src, dst){
    if(dst.r < src.r) return { word: 'naar boven', arrow: '↑' };
    if(dst.r > src.r) return { word: 'naar beneden', arrow: '↓' };
    if(dst.c < src.c) return { word: 'naar links', arrow: '←' };
    if(dst.c > src.c) return { word: 'naar rechts', arrow: '→' };
    return { word: 'naar het lege vak', arrow: '' };
  }

  // Vertelt of een tegel in een hoek, rand of het midden staat
  function positionLabel(r,c){
    const top = (r === 0);
    const bottom = (r === SIZE - 1);
    const left = (c === 0);
    const right = (c === SIZE - 1);

    if(top && left) return 'hoek linksboven';
    if(top && right) return 'hoek rechtsboven';
    if(bottom && left) return 'hoek linksonder';
    if(bottom && right) return 'hoek rechtsonder';

    if(top) return 'bovenrij';
    if(bottom) return 'onderrij';
    if(left) return 'linkerkant';
    if(right) return 'rechterkant';
    return 'midden';
  }

  // Zet zo'n positie-label om naar een vloeiende zin
  function positionText(label, context='target'){
    switch(label){
      case 'hoek linksboven':
        return context === 'target' ? 'de hoek linksboven' : 'in de hoek linksboven';
      case 'hoek rechtsboven':
        return context === 'target' ? 'de hoek rechtsboven' : 'in de hoek rechtsboven';
      case 'hoek linksonder':
        return context === 'target' ? 'de hoek linksonder' : 'in de hoek linksonder';
      case 'hoek rechtsonder':
        return context === 'target' ? 'de hoek rechtsonder' : 'in de hoek rechtsonder';
      case 'bovenrij':
        return context === 'target' ? 'de bovenste rij' : 'op de bovenste rij';
      case 'onderrij':
        return context === 'target' ? 'de onderste rij' : 'op de onderste rij';
      case 'linkerkant':
        return context === 'target' ? 'de linkerkant' : 'aan de linkerkant';
      case 'rechterkant':
        return context === 'target' ? 'de rechterkant' : 'aan de rechterkant';
      case 'midden':
      default:
        return context === 'target' ? 'het midden' : 'in het midden';
    }
  }

  // Vertaal een richting-code naar woorden voor de coach
  function tutorialDirectionText(dir){
    switch(dir){
      case 'up': return 'naar boven';
      case 'down': return 'naar beneden';
      case 'left': return 'naar links';
      case 'right': return 'naar rechts';
      default: return 'naar het lege vak';
    }
  }

  // Bouwt een stappenplan op basis van een lijst indices
  function buildHintPlan(indices){
    if(!Array.isArray(indices) || !indices.length) return null;
    let sim = state.slice();
    let emptyIndex = sim.indexOf(0);
    if(emptyIndex === -1) return null;
    const initialScore = manhattanScore(sim);
    let score = initialScore;
    const steps = [];
    for(let idx=0; idx<indices.length; idx++){
      const moveIndex = indices[idx];
      if(moveIndex === null || moveIndex === undefined) break;
      if(moveIndex < 0 || moveIndex >= sim.length) break;
      const tileVal = sim[moveIndex];
      if(tileVal === 0) break;
      const srcRC = indexToRC(moveIndex);
      const dstRC = indexToRC(emptyIndex);
      const dir = describeDirection(srcRC, dstRC);
      const next = cloneSwap(sim, moveIndex, emptyIndex);
      const nextScore = manhattanScore(next);
      const goalR = Math.floor((tileVal-1)/SIZE);
      const goalC = (tileVal-1)%SIZE;
      const distBefore = Math.abs(goalR - srcRC.r) + Math.abs(goalC - srcRC.c);
      const distAfter = Math.abs(goalR - dstRC.r) + Math.abs(goalC - dstRC.c);
      steps.push({
        step: idx + 1,
        index: moveIndex,
        tile: tileVal,
        direction: dir.word,
        arrow: dir.arrow,
        delta: score - nextScore,
        distBefore,
        distAfter
      });
      sim = next;
      emptyIndex = moveIndex;
      score = nextScore;
    }
    if(!steps.length) return null;
    return {
      steps,
      totalDelta: initialScore - score,
      finalScore: score
    };
  }

  // Laat de coach uitleggen waarom deze hint slim is
  function coachExplainHint(tileIndex, planInfo=null){
    if(!coachEl) return;
    const empty = state.indexOf(0);
    if(empty === -1) return;
    const tileVal = state[tileIndex];
    if(tileVal === 0) return;
    const src = indexToRC(tileIndex);
    const dst = indexToRC(empty);
    const beforeScore = manhattanScore(state);
    const next = cloneSwap(state, tileIndex, empty);
    const afterScore = manhattanScore(next);
    const goalR = Math.floor((tileVal-1)/SIZE);
    const goalC = (tileVal-1)%SIZE;
    const distBefore = Math.abs(goalR - src.r) + Math.abs(goalC - src.c);
    const distAfter = Math.abs(goalR - dst.r) + Math.abs(goalC - dst.c);
    const distDelta = distBefore - distAfter;
    const scoreDelta = beforeScore - afterScore;
    const dir = describeDirection(src, dst);
    const targetRow = goalR + 1;
    const targetCol = goalC + 1;
    const fromRow = src.r + 1;
    const fromCol = src.c + 1;
    const arrowText = dir.arrow ? ` (${dir.arrow})` : '';
    const sentences = [];
    const targetLabel = positionLabel(goalR, goalC);
    const currentLabel = positionLabel(src.r, src.c);
    sentences.push(`Breng tegel ${tileVal} naar ${positionText(targetLabel, 'target')}.`);
    sentences.push(`Hij staat nu ${positionText(currentLabel, 'current')}.`);

    let moveSentence = `Schuif ${dir.word}`;
    if(dir.arrow) moveSentence += ` (${dir.arrow})`;
    if(distAfter === 0){
      moveSentence += '. Daarna ligt hij meteen goed.';
    } else if(distDelta > 0){
      moveSentence += '. Zo schuift hij dichter bij zijn plek.';
    } else {
      moveSentence += '. Zo maak je ruimte om verder te leggen.';
    }
    sentences.push(moveSentence);

    if(planInfo && planInfo.steps && planInfo.steps.length){
      const limitedSteps = planInfo.steps.slice(0, 2);
      const stepSentence = limitedSteps.map(step => {
        const arrow = step.arrow ? ` (${step.arrow})` : '';
        let reason = '';
        if(step.distAfter === 0){
          reason = 'Dan ligt hij precies goed.';
        } else if(step.delta > 0){
          reason = 'Zo schuift hij verder richting de juiste plek.';
        } else {
          reason = 'Zo maak je eerst ruimte.';
        }
        return `Daarna schuif je tegel ${step.tile} ${step.direction}${arrow}. ${reason}`;
      }).join(' ');
      sentences.push(stepSentence);
      if(planInfo.finalScore === 0){
        sentences.push('Na deze stappen is de puzzel klaar.');
      }
    }

    const duration = 6200 + (planInfo && planInfo.steps ? planInfo.steps.length * 1600 : 0);
    setCoachMessage(`Hint: tegel ${tileVal}`, sentences.join(' '), true, duration);
  }

  // Past de tekst en aria-eigenschappen van de geluidsknop aan
  function updateSoundToggleUI(){
    if(!soundToggleBtn) return;
    soundToggleBtn.setAttribute('aria-pressed', soundEnabled ? 'true' : 'false');
    soundToggleBtn.textContent = soundEnabled ? '🔊 Geluid aan' : '🔇 Geluid uit';
  }

  // Zet de Web Audio-context klaar en maakt een master gain
  function ensureAudioContext(){
    if(!soundEnabled) return null;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if(!AudioCtx) return null;
    if(!audioState.ctx){
      try {
        audioState.ctx = new AudioCtx();
      } catch {
        return null;
      }
      audioState.master = audioState.ctx.createGain();
      const initial = soundEnabled ? 0.35 : 0.0001;
      audioState.master.gain.setValueAtTime(initial, audioState.ctx.currentTime);
      audioState.master.connect(audioState.ctx.destination);
    } else if(audioState.ctx.state === 'suspended'){
      audioState.ctx.resume().catch(()=>{});
    }
    return audioState.ctx;
  }

  // Speelt een kort geluidje met een bepaalde toon en duur
  function scheduleTone(ctx, freq, start, duration, type='sine', volume=0.22){
    if(!audioState.master) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);
    const attack = Math.min(0.02, duration * 0.45);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(Math.max(volume, 0.0002), start + attack);
    gain.gain.linearRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(audioState.master);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  }

  // Maakt een ruis-buffer voor zachte klikjes en effecten
  function getNoiseBuffer(ctx){
    if(audioState.noiseBuffer) return audioState.noiseBuffer;
    const length = Math.floor(ctx.sampleRate * 0.35);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for(let i=0;i<length;i++){
      const fade = Math.pow(1 - (i/length), 0.55);
      data[i] = (Math.random()*2 - 1) * fade;
    }
    audioState.noiseBuffer = buffer;
    return buffer;
  }

  // Speelt een zacht klikje wanneer je een tegel beweegt
  function playMoveSound(){
    const ctx = ensureAudioContext();
    if(!ctx) return;
    const t = ctx.currentTime;
    const source = ctx.createBufferSource();
    source.buffer = getNoiseBuffer(ctx);
    source.playbackRate.setValueAtTime(1.08, t);

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(420, t);
    filter.Q.setValueAtTime(0.8, t);
    filter.frequency.exponentialRampToValueAtTime(1600, t + 0.18);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(0.28, t + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(audioState.master);

    source.start(t);
    source.stop(t + 0.34);

  }

  // Klein geluidje zodat je merkt dat er een hint actief is
  function playHintSound(){
    const ctx = ensureAudioContext();
    if(!ctx) return;
    const t = ctx.currentTime;
    scheduleTone(ctx, 840, t, 0.12, 'sine', 0.16);
    scheduleTone(ctx, 1180, t + 0.06, 0.1, 'sine', 0.12);
  }

  // Speelt een vrolijk akkoord als je wint
  function playWinSound(){
    const ctx = ensureAudioContext();
    if(!ctx) return;
    const t = ctx.currentTime;
    [523, 659, 784].forEach((freq, idx)=>{
      const start = t + idx * 0.18;
      scheduleTone(ctx, freq, start, 0.32, idx === 2 ? 'triangle' : 'sine', 0.24);
    });
  }

  // Speelt een kort foutgeluid wanneer iets niet mag
  function playErrorSound(){
    const ctx = ensureAudioContext();
    if(!ctx) return;
    const t = ctx.currentTime;
    scheduleTone(ctx, 220, t, 0.26, 'sawtooth', 0.2);
    scheduleTone(ctx, 170, t + 0.08, 0.3, 'triangle', 0.14);
  }

  // Speelt tikken en een ping tijdens het aftellen
  function playCountdownSound(step){
    const ctx = ensureAudioContext();
    if(!ctx) return;
    const t = ctx.currentTime;
    if(step === 'GO!'){
      scheduleTone(ctx, 880, t, 0.18, 'triangle', 0.22);
      scheduleTone(ctx, 1310, t + 0.04, 0.22, 'sine', 0.18);
      return;
    }
    const n = Number(step);
    if(Number.isFinite(n)){
      const freq = 380 + (3 - n) * 80;
      scheduleTone(ctx, freq, t, 0.16, 'sine', 0.16);
    }
  }

  // Slaat op of geluid aan staat en update de knop
  function setSoundEnabled(flag){
    soundEnabled = !!flag;
    if(soundEnabled){
      const ctx = ensureAudioContext();
      if(ctx && audioState.master){
        const now = ctx.currentTime;
        audioState.master.gain.cancelScheduledValues(now);
        audioState.master.gain.setTargetAtTime(0.35, now, 0.08);
      }
    } else if(audioState.master && audioState.ctx){
      const now = audioState.ctx.currentTime;
      audioState.master.gain.cancelScheduledValues(now);
      audioState.master.gain.setTargetAtTime(0.0001, now, 0.08);
    }
    updateSoundToggleUI();
    try { localStorage.setItem(SOUND_PREF_KEY, soundEnabled ? 'on' : 'off'); } catch {}
  }

  // Koppelt de geluidsknop en laadt eerdere voorkeuren
  function initSoundControls(){
    try {
      const stored = localStorage.getItem(SOUND_PREF_KEY);
      if(stored === 'off') soundEnabled = false;
    } catch {}
    updateSoundToggleUI();
    if(soundToggleBtn){
      soundToggleBtn.addEventListener('click', ()=>{
        setSoundEnabled(!soundEnabled);
      });
    }
  }

  // Checkt of het matrix-thema actief is
  function isMatrixTheme(){
    return document.body.getAttribute('data-theme') === 'matrix';
  }

  // Laat een tegeltekst even flikkeren voor het Matrix-thema
  function scrambleTile(el, finalText, duration=200){
    if(!el || el.dataset.scrambling === '1') return;
    el.dataset.scrambling = '1';
    const glyphs = '01ｱｲｳｴｵｶｷｸｹｺﾅﾆﾇﾈﾉﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛ';
    const start = performance.now();
    let last = start;
    function step(now){
      const t = (now - start) / duration;
      if(t >= 1){
        el.textContent = finalText;
        delete el.dataset.scrambling;
        return;
      }
      if(now - last > 30){
        el.textContent = glyphs.charAt(Math.floor(Math.random() * glyphs.length));
        last = now;
      }
      requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // Zet seconden om naar mm:ss
  function fmtTime(s){
    const m = Math.floor(s/60).toString().padStart(2,'0');
    const ss = (s%60).toString().padStart(2,'0');
    return `${m}:${ss}`;
  }

  // Start de stopwatch en telt elke seconde omhoog
  function startTimer(){
    if(timer) return;
    timer = setInterval(()=>{
      seconds++;
      timeEl.textContent = fmtTime(seconds);
    }, 1000);
  }
  // Pauzeert de stopwatch
  function stopTimer(){
    if(timer){ clearInterval(timer); timer = null; }
  }
  // Zet moves, tijd, hints en timer terug naar nul
  function resetStats(){
    moves = 0; seconds = 0; started = false;
    movesEl.textContent = '0';
    timeEl.textContent = '00:00';
    updateStatus('Aan het spelen');
    stopTimer();
    resetCoach();
  }

  // Tekent het bord opnieuw en werkt alle UI-elementen bij
  function render(){
    // grid-kolommen dynamisch instellen
    boardEl.style.gridTemplateColumns = `repeat(${SIZE}, 1fr)`;
    boardEl.style.setProperty('--board-size', SIZE);
    document.title = `MindShift – Puzzle (${SIZE}×${SIZE})`;
    boardEl.innerHTML = '';
    let pulseSpawned = false;
    let quakeOriginIndex = -1;
    if(isMatrixTheme() && moveFX){
      quakeOriginIndex = state.indexOf(moveFX.val);
    }
    state.forEach((val, idx)=>{
      const tile = document.createElement('button');
      tile.className = 'tile' + (val===0 ? ' empty' : '');
      tile.setAttribute('role','gridcell');
      tile.setAttribute('aria-label', val===0 ? 'Empty' : `Tile ${val}`);
      tile.dataset.index = idx;
      tile.textContent = val===0 ? '' : val;
      // Matrix move effect: mark the tile that just moved
      if(val!==0 && moveFX && moveFX.val === val){
        tile.classList.add('moveFx', `from-${moveFX.from}`);
        requestAnimationFrame(()=>{
          tile.animate([
            { transform: 'scale(0.94)' },
            { transform: 'scale(1.06)' },
            { transform: 'scale(1)' }
          ], { duration: 220, easing: 'cubic-bezier(.22,.61,.36,1)' });
        });
      }
      // Earthquake ripple: distance-based shake per tile
      if(isMatrixTheme() && quakeOriginIndex !== -1 && val !== 0){
        const a = indexToRC(idx);
        const b = indexToRC(quakeOriginIndex);
        const dist = Math.abs(a.r - b.r) + Math.abs(a.c - b.c);
        const amp = Math.max(0, 6 - dist); // px
        const delay = dist * 28; // ms
        if(amp > 0){
          tile.classList.add('qShake');
          tile.style.setProperty('--q-amp', amp + 'px');
          tile.style.setProperty('--q-delay', delay + 'ms');
        }
      }
      tile.addEventListener('click', ()=> tryMove(idx));
      boardEl.appendChild(tile);
      if(!pulseSpawned && val!==0 && moveFX && moveFX.val === val && isMatrixTheme()){
        scrambleTile(tile, String(val), 220);
        spawnMatrixPulse(tile, moveFX.from);
        spawnMatrixBolt(tile, moveFX.from);
        pulseSpawned = true;
      }
    });
    if(isMatrixTheme() && quakeOriginIndex !== -1){
      triggerBoardQuake();
    }
    if(tutorialState.active && tutorialState.stage === 0){
      if(tutorialState.highlightTileIndex === null){
        showTutorialFirstMoveCue();
      } else {
        positionPointer();
      }
    }
  }

  // Laat het bord kort trillen voor feedback
  function triggerBoardQuake(){
    boardEl.classList.remove('boardQuake');
    // Force reflow so animation retriggers
    void boardEl.offsetWidth;
    boardEl.classList.add('boardQuake');
    setTimeout(()=> boardEl.classList.remove('boardQuake'), 500);
  }

  // Maakt een pulserende lichtvlek voor het Matrix-thema
  function spawnMatrixPulse(tileEl, from){
    const boardRect = boardEl.getBoundingClientRect();
    const tileRect = tileEl.getBoundingClientRect();
    const cx = tileRect.left - boardRect.left + tileRect.width/2;
    const cy = tileRect.top - boardRect.top + tileRect.height/2;
    const pulse = document.createElement('span');
    pulse.className = 'matrix-pulse';
    pulse.style.left = cx + 'px';
    pulse.style.top = cy + 'px';
    pulse.style.width = tileRect.width + 'px';
    pulse.style.height = tileRect.width + 'px';
    boardEl.appendChild(pulse);
    const remove = ()=>{ if(pulse && pulse.parentNode) pulse.parentNode.removeChild(pulse); };
    pulse.addEventListener('animationend', remove, { once: true });
    // Fallback removal
    setTimeout(remove, 700);

    // Spawn ripple waves (2-3 rings) for ripple effect
    const rippleCount = 2; // extra rings for layered wave effect
    const rippleDelay = 70; // ms between ripples
    for(let i=0; i<rippleCount; i++){
      const ripple = document.createElement('span');
      ripple.className = 'matrix-ripple';
      ripple.style.left = cx + 'px';
      ripple.style.top = cy + 'px';
      ripple.style.width = tileRect.width + 'px';
      ripple.style.height = tileRect.width + 'px';
      ripple.style.animationDelay = (i * rippleDelay) + 'ms';
      boardEl.appendChild(ripple);
      const cleanup = ()=>{ if(ripple && ripple.parentNode) ripple.parentNode.removeChild(ripple); };
      ripple.addEventListener('animationend', cleanup, { once: true });
      setTimeout(cleanup, 1200);
    }
  }

  // Laat een neon-streep over het bord lopen in Matrix-stijl
  function spawnMatrixBolt(tileEl, from){
    const boardRect = boardEl.getBoundingClientRect();
    const tileRect = tileEl.getBoundingClientRect();
    const cx = tileRect.left - boardRect.left + tileRect.width/2;
    const cy = tileRect.top - boardRect.top + tileRect.height/2;

    const glyphs = '01ﾗﾘﾙﾚﾛｱｲｳｴｵ';
    const makeText = (n)=> Array.from({length:n}, ()=> glyphs[Math.floor(Math.random()*glyphs.length)]).join('');

    const bolt = document.createElement('span');
    bolt.className = 'matrix-bolt';
    const dir = (from === 'left' || from === 'right') ? 'x' : 'y';
    bolt.classList.add(dir === 'x' ? 'dir-x' : 'dir-y');
    bolt.style.left = cx + 'px';
    bolt.style.top = cy + 'px';

    const cs = getComputedStyle(boardEl);
    let gap = 8;
    try {
      const raw = (cs.columnGap || cs.gap || '8px').toString();
      const m = raw.match(/([0-9.]+)/);
      if(m) gap = parseFloat(m[1]);
    } catch {}
    const len = tileRect.width + gap;
    if(dir === 'x'){
      bolt.style.width = Math.round(len) + 'px';
      bolt.style.height = '14px';
      bolt.style.fontSize = '12px';
      bolt.textContent = makeText(18);
    } else {
      bolt.style.width = '14px';
      bolt.style.height = Math.round(len) + 'px';
      bolt.style.fontSize = '12px';
      bolt.textContent = makeText(18);
    }
    boardEl.appendChild(bolt);
    const cleanup = ()=>{ if(bolt && bolt.parentNode) bolt.parentNode.removeChild(bolt); };
    bolt.addEventListener('animationend', cleanup, { once: true });
    setTimeout(cleanup, 800);
  }

  // Zet een index om naar rij en kolom
  function indexToRC(i){ return {r: Math.floor(i/SIZE), c: i%SIZE}; }
  // Zet rij en kolom om naar één index
  function rcToIndex(r,c){ return r*SIZE + c; }

  // Geeft alle indices die naast een vakje liggen
  function neighborsOf(i){
    const {r,c} = indexToRC(i);
    const ns = [];
    if(r>0) ns.push(rcToIndex(r-1,c));
    if(r<SIZE-1) ns.push(rcToIndex(r+1,c));
    if(c>0) ns.push(rcToIndex(r,c-1));
    if(c<SIZE-1) ns.push(rcToIndex(r,c+1));
    return ns;
  }

  // Manhattan-heuristiek: som van afstanden per tegel naar doelpositie
  // Telt hoeveel stappen alle tegels nog van hun plek af zitten
  function manhattanScore(arr){
    let score = 0;
    for(let idx=0; idx<arr.length; idx++){
      const v = arr[idx];
      if(v===0) continue;
      const goalR = Math.floor((v-1)/SIZE);
      const goalC = (v-1)%SIZE;
      const {r,c} = indexToRC(idx);
      score += Math.abs(goalR - r) + Math.abs(goalC - c);
    }
    return score;
  }

  // Kijkt of tegels elkaar blokkeren in dezelfde rij of kolom
  function linearConflict(arr){
    let conflicts = 0;
    // row conflicts
    for(let r=0; r<SIZE; r++){
      for(let c1=0; c1<SIZE; c1++){
        const idx1 = rcToIndex(r, c1);
        const v1 = arr[idx1];
        if(v1===0) continue;
        const goalRow1 = Math.floor((v1-1)/SIZE);
        const goalCol1 = (v1-1)%SIZE;
        if(goalRow1 !== r) continue;
        for(let c2=c1+1; c2<SIZE; c2++){
          const idx2 = rcToIndex(r, c2);
          const v2 = arr[idx2];
          if(v2===0) continue;
          const goalRow2 = Math.floor((v2-1)/SIZE);
          const goalCol2 = (v2-1)%SIZE;
          if(goalRow2 !== r) continue;
          if(goalCol1 > goalCol2) conflicts++;
        }
      }
    }
    // column conflicts
    for(let c=0; c<SIZE; c++){
      for(let r1=0; r1<SIZE; r1++){
        const idx1 = rcToIndex(r1, c);
        const v1 = arr[idx1];
        if(v1===0) continue;
        const goalRow1 = Math.floor((v1-1)/SIZE);
        const goalCol1 = (v1-1)%SIZE;
        if(goalCol1 !== c) continue;
        for(let r2=r1+1; r2<SIZE; r2++){
          const idx2 = rcToIndex(r2, c);
          const v2 = arr[idx2];
          if(v2===0) continue;
          const goalRow2 = Math.floor((v2-1)/SIZE);
          const goalCol2 = (v2-1)%SIZE;
          if(goalCol2 !== c) continue;
          if(goalRow1 > goalRow2) conflicts++;
        }
      }
    }
    return conflicts * 2;
  }

  // Combineert afstand en conflicten tot één score
  function idaHeuristic(arr){
    return manhattanScore(arr) + linearConflict(arr);
  }

  // Maakt een kopie van het bord en wisselt twee plekken om
  function cloneSwap(a, i, j){
    const b = a.slice();
    const t = b[i]; b[i] = b[j]; b[j] = t;
    return b;
  }

  // Kies een buurtegel die de Manhattan-score het meest verlaagt (greedy)
  // Zoekt welke buur-tegel nu de grootste vooruitgang geeft
  function greedyHintIndex(board = state, empty = board.indexOf(0), prevEmpty = prevEmptyIndex){
    if(empty === -1) return null;
    const movesIdx = neighborsOf(empty);
    if(!movesIdx.length) return null;
    const baseScore = manhattanScore(board);
    const scoreMove = (i)=>{
      const next = cloneSwap(board, i, empty);
      const score = manhattanScore(next);
      const tie = next.reduce((acc,v,idx)=> acc + ((v!==0 && v!==GOAL[idx])?1:0), 0);
      return { idx: i, score, tie };
    };
    const pickBest = (candidates)=>{
      let best = null;
      let bestScore = Infinity;
      let bestTie = Infinity;
      let bestDelta = Infinity;
      for(const i of candidates){
        const {score, tie} = scoreMove(i);
        const delta = score - baseScore;
        if(
          score < bestScore ||
          (score === bestScore && tie < bestTie) ||
          (score === bestScore && tie === bestTie && delta < bestDelta)
        ){
          best = i; bestScore = score; bestTie = tie; bestDelta = delta;
        }
      }
      return best;
    };

    const nonReversals = movesIdx.filter(i => i !== prevEmpty);
    let choice = pickBest(nonReversals);
    if(choice !== null && choice !== undefined) return choice;
    choice = pickBest(movesIdx);
    if(choice !== null && choice !== undefined) return choice;
    return movesIdx.length ? movesIdx[0] : null;
  }

  // Maakt van het bord een string zodat we kunnen vergelijken
  function serializeState(arr){
    return arr.join(',');
  }

  // Zoek met beperkte IDA* naar een exacte oplossing en geef de eerste zet terug
  // Probeert met een slimme zoekactie een exact stappenplan te vinden
  function exactHintPlan(){
    if(SIZE > 4) return null; // vermijd dure zoektochten voor grotere borden
    const start = state.slice();
    const startScore = idaHeuristic(start);
    if(startScore === 0) return null;
    const maxNodes = 2000000;
    const timeLimit = 2000; // ms
    const startTime = performance.now ? performance.now() : Date.now();
    const now = performance.now ? ()=>performance.now() : ()=>Date.now();
    let nodes = 0;
    let threshold = startScore;
    const path = [];

    const search = (current, g, limit, emptyPrev, visited)=>{
      nodes++;
      if(nodes > maxNodes) return 'timeout';
      if(now() - startTime > timeLimit) return 'timeout';
      const h = idaHeuristic(current);
      const f = g + h;
      if(f > limit) return f;
      if(h === 0) return true;
      const emptyIdx = current.indexOf(0);
      const movesIdx = neighborsOf(emptyIdx);
      const moves = [];
      for(const move of movesIdx){
        if(move === emptyPrev) continue; // voorkom onmiddellijke reversal
        const next = cloneSwap(current, move, emptyIdx);
        const key = serializeState(next);
        if(visited.has(key)) continue;
        moves.push({ move, next, key, score: idaHeuristic(next) });
      }
      moves.sort((a,b)=> a.score - b.score);
      let min = Infinity;
      for(const {move, next, key} of moves){
        visited.add(key);
        path.push(move);
        const res = search(next, g+1, limit, emptyIdx, visited);
        if(res === true) return true;
        if(res === 'timeout') return 'timeout';
        if(res < min) min = res;
        path.pop();
        visited.delete(key);
      }
      return min;
    };

    while(threshold <= 80){
      path.length = 0;
      nodes = 0;
      const visited = new Set([serializeState(start)]);
      const result = search(start, 0, threshold, -1, visited);
      if(result === true){
        const bestPath = path.slice(0, 6);
        const move = bestPath[0];
        path.length = 0;
        if(move === undefined) return null;
        return { index: move, plan: bestPath };
      }
      if(result === 'timeout') break;
      if(!Number.isFinite(result)) break;
      threshold = result;
    }
    path.length = 0;
    return null;
  }

  // Zet de hintknop aan of uit en toont een busy-staat
  function setHintButtonDisabled(flag){
    if(!hintBtn) return;
    hintBtn.disabled = !!flag;
    hintBtn.classList.toggle('is-busy', !!flag);
    hintBtn.setAttribute('aria-busy', flag ? 'true' : 'false');
  }

  // Als er oude auto-hint state was blijft deze helper het netjes opruimen
  function finishAutoHint(){
    if(autoHintTimer){
      clearTimeout(autoHintTimer);
      autoHintTimer = null;
    }
    autoHintQueue = [];
    autoHintExecuting = false;
    if(autoHintActive){
      autoHintActive = false;
      setHintButtonDisabled(false);
    }
  }

  // Kleine helper die finishAutoHint blijft aanroepen
  function cancelAutoHint(){
    finishAutoHint();
  }

  // Bepaalt hoeveel stappen we maximaal in de hinttekst laten zien
  function getAutoHintStepCount(planInfo){
    if(!planInfo || !Array.isArray(planInfo.steps) || !planInfo.steps.length) return 0;
    if(SIZE < 3 || SIZE > 5) return 0;
    const limit = SIZE === 3 ? 2 : 3;
    return Math.min(planInfo.steps.length, limit);
  }

  // Historische helper: vroeger filterde dit de auto-hint moves
  function trimAutoHintSequence(sequence){
    if(!Array.isArray(sequence) || !sequence.length) return [];
    const working = state.slice();
    let emptyIdx = working.indexOf(0);
    const trimmed = [];
    for(let i=0;i<sequence.length;i++){
      const tileVal = sequence[i];
      const tileIdx = working.indexOf(tileVal);
      if(tileIdx === -1) break;
      if(!neighborsOf(emptyIdx).includes(tileIdx)) break;
      // apply move in simulation
      [working[tileIdx], working[emptyIdx]] = [working[emptyIdx], working[tileIdx]];
      emptyIdx = tileIdx;
      const solved = working.every((val, idx)=> val === GOAL[idx]);
      if(solved){
        break; // don't include move that solves entirely
      }
      trimmed.push(tileVal);
    }
    return trimmed;
  }

  // Historische helper voor automatische hints (nu nooit meer aangeroepen)
  function runNextAutoHintStep(){
    if(!autoHintQueue.length){
      finishAutoHint();
      return;
    }
    const tileVal = autoHintQueue.shift();
    const tileIndex = state.indexOf(tileVal);
    if(tileIndex === -1){
      finishAutoHint();
      return;
    }
    autoHintExecuting = true;
    tryMove(tileIndex);
    autoHintExecuting = false;
    if(autoHintQueue.length){
      autoHintTimer = setTimeout(runNextAutoHintStep, 760);
    } else {
      autoHintTimer = setTimeout(finishAutoHint, 420);
    }
  }

  // Automatische hints staan uit, deze functie doet bewust niets meer
  function queueAutoHint(_tileSequence){
    // Bewust leeg: auto-hints zijn nu uitgeschakeld
  }

  // Bouwt een kort plan door telkens de beste buur te pakken
  function buildGreedyPlanIndices(maxSteps=3){
    const plan = [];
    let working = state.slice();
    let empty = working.indexOf(0);
    let prev = prevEmptyIndex;
    for(let step=0; step<maxSteps; step++){
      const move = greedyHintIndex(working, empty, prev);
      if(move === null || move === undefined) break;
      plan.push(move);
      const next = cloneSwap(working, move, empty);
      prev = empty;
      empty = move;
      working = next;
      if(working.every((val, idx)=> val === GOAL[idx])) break;
    }
    return plan;
  }

  // Combineert exacte zoekresultaten met een greedy fallback
  function computeHintSuggestion(){
    const exact = exactHintPlan();
    if(exact && exact.index !== null && exact.index !== undefined){
      const indices = Array.isArray(exact.plan) && exact.plan.length ? exact.plan.slice(0, 6) : [exact.index];
      const info = buildHintPlan(indices);
      return {
        primaryIndex: exact.index,
        planIndices: indices,
        planInfo: info,
        tileSequence: info && Array.isArray(info.steps) ? info.steps.map(step => step.tile) : [],
        primaryTile: state[exact.index] || null
      };
    }
    let greedyPlan = buildGreedyPlanIndices(4);
    if(!greedyPlan.length){
      const fallback = greedyHintIndex();
      if(fallback !== null && fallback !== undefined){
        greedyPlan = [fallback];
      }
    }
    if(greedyPlan.length){
      const indices = greedyPlan.slice();
      const info = buildHintPlan(indices);
      return {
        primaryIndex: indices[0],
        planIndices: indices,
        planInfo: info,
        tileSequence: info && Array.isArray(info.steps) ? info.steps.map(step => step.tile) : [],
        primaryTile: state[indices[0]] || null
      };
    }
    return null;
  }

  // Zet een pijl bij de tegel die je moet schuiven
  function showHintArrow(index){
    const tile = boardEl.querySelector(`.tile[data-index="${index}"]`);
    if(!tile || tile.classList.contains('empty')) return;
    const emptyIndex = state.indexOf(0);
    const emptyTile = boardEl.querySelector(`.tile[data-index="${emptyIndex}"]`);
    const boardRect = boardEl.getBoundingClientRect();
    const tileRect = tile.getBoundingClientRect();
    const emptyRect = emptyTile ? emptyTile.getBoundingClientRect() : null;
    if(tileRect && emptyRect){
      tile.classList.add('hint-target');
      const arrow = document.createElement('span');
      arrow.className = 'hint-arrow';
      const direction = computeDirectionIcon(tileRect, emptyRect);
      arrow.textContent = direction;
      const arrowWidth = Math.min(Math.max(tileRect.width * 0.36, 36), 60);
      const arrowHeight = Math.min(Math.max(tileRect.height * 0.26, 20), 32);
      arrow.style.width = arrowWidth + 'px';
      arrow.style.height = arrowHeight + 'px';
      arrow.style.lineHeight = arrowHeight + 'px';
      const midpoint = midpointOnEdge(tileRect, emptyRect);
      boardEl.appendChild(arrow);
      arrow.style.left = (midpoint.x - boardRect.left - arrowWidth/2) + 'px';
      arrow.style.top = (midpoint.y - boardRect.top - arrowHeight/2) + 'px';
      setTimeout(()=>{
        if(arrow.parentNode) arrow.parentNode.removeChild(arrow);
        tile.classList.remove('hint-target');
      }, 1600);
    }
  }

  // Speelt een hint af: coachtekst plus een pijl naar de juiste tegel
  function performCoachHint(source='button'){
    if(isInteractionLocked()) return;
    let solved = true;
    for(let i=0;i<GOAL.length;i++){ if(state[i]!==GOAL[i]) { solved = false; break; } }
    if(solved) return;
    if(!isSolvable(state, SIZE)){
      warnUnsolvable();
      return;
    }

    const suggestion = computeHintSuggestion();
    if(!suggestion || suggestion.primaryIndex === null || suggestion.primaryIndex === undefined) return;

    const tileValue = suggestion.primaryTile || state[suggestion.primaryIndex];

    const planSteps = suggestion.planInfo && Array.isArray(suggestion.planInfo.steps)
      ? suggestion.planInfo.steps
      : [];

    const rawStepCount = getAutoHintStepCount(suggestion.planInfo);
    const desiredSteps = planSteps.length ? Math.max(rawStepCount, 1) : 0;
    const messageStepCount = planSteps.length
      ? Math.min(planSteps.length, desiredSteps)
      : 0;
    const coachPlan = suggestion.planInfo && planSteps.length
      ? { ...suggestion.planInfo, steps: planSteps.slice(0, messageStepCount) }
      : suggestion.planInfo;

    hintCount++;
    recordHintUsage();
    appendEvent('hint', {
      tile: tileValue,
      index: suggestion.primaryIndex,
      board: state.slice(),
      plan: coachPlan && Array.isArray(coachPlan.steps)
        ? coachPlan.steps.map(step => step.index)
        : null,
      autoTiles: [],
      source
    });
    playHintSound();
    coachExplainHint(suggestion.primaryIndex, coachPlan);
    handleTutorialHintUsed();
    if(liveRegion) liveRegion.textContent = `Hint: schuif tegel ${tileValue}`;
    showHintArrow(suggestion.primaryIndex);
  }

  // Laat weten dat dit bord niet oplosbaar is
  function warnUnsolvable(){
    playErrorSound();
    appendEvent('unsolvable', { board: state.slice() });
    setCoachMessage('Geen oplossing', 'Dit bord is niet op te lossen. Start een nieuw spel of kies een andere seed.', true, 5200);
    // Visual, non-transforming warning on the board
    boardEl.classList.remove('unsolvable');
    // force reflow to restart animation
    void boardEl.offsetWidth;
    boardEl.classList.add('unsolvable');
    // Announce via live region and update visible status briefly
    if(liveRegion) liveRegion.textContent = 'Deze positie is onoplosbaar. Start een nieuw spel.';
    flashStatus('Onoplosbaar');
  }

  // Probeert een tegel te verplaatsen en registreert de zet
  function tryMove(i){
    if(isInteractionLocked()) return;
    if(autoHintActive && !autoHintExecuting){
      cancelAutoHint();
    }
    const emptyIndex = state.indexOf(0);
    if(neighborsOf(i).includes(emptyIndex)){
      // capture move direction and value for animation
      const movedVal = state[i];
      const src = indexToRC(i);
      const dst = indexToRC(emptyIndex);
      let from = 'left';
      if(dst.r - src.r === 1) from = 'top';       // moved down -> enters from top
      else if(dst.r - src.r === -1) from = 'bottom'; // moved up -> enters from bottom
      else if(dst.c - src.c === 1) from = 'left'; // moved right -> enters from left
      else if(dst.c - src.c === -1) from = 'right'; // moved left -> enters from right
      moveFX = { val: movedVal, from };
      playMoveSound();
      prevEmptyIndex = emptyIndex;
      [state[i], state[emptyIndex]] = [state[emptyIndex], state[i]];
      if(!started){ started = true; startTimer(); }
      moves++; movesEl.textContent = String(moves);
      tutorialState.lastMoveTile = movedVal;
      appendEvent('move', {
        tile: movedVal,
        fromIndex: i,
        toIndex: emptyIndex,
        newEmptyIndex: i,
        direction: from,
        board: state.slice()
      });
      handleTutorialAfterMove();
      render();
      checkWin();
    } else {
      playErrorSound();
      bounceTile(i);
      flashStatus('Geblokkeerd', 900);
    }
  }

  // Controleert of alles op de juiste plek ligt en handelt de winst af
  function checkWin(){
    for(let i=0;i<GOAL.length;i++){ if(state[i]!==GOAL[i]) return; }
    cancelAutoHint();
    stopTimer();
    appendEvent('win', {
      durationMs: Date.now() - gameStartTime,
      moves,
      hints: hintCount,
      board: state.slice(),
      mode: currentGameMode
    });
    playWinSound();
    updateStatus('Opgelost!');
    const badge = computeBadge();
    lastWinProgression = handleWinProgression();
    if(lastWinProgression){
      appendEvent('xp_gain', {
        xp: lastWinProgression.xpGain,
        level: lastWinProgression.level,
        leveledUp: lastWinProgression.leveledUp,
        mode: currentGameMode
      });
    }
    announceWinAchievements(badge, lastWinProgression);
    document.querySelectorAll('.tile').forEach((el)=>{
      if(el.textContent!=='') el.classList.add('win');
    });
    if(boardEl) boardEl.classList.add('board-win');
    spawnConfettiBurst();
    showWinScreen();
  }
  // Fisher-Yates shuffle die blijft proberen tot het bord oplosbaar is
  function shuffledSolvable(rng){
    const arr = GOAL.slice();
    do {
      for(let i=arr.length-1;i>0;i--){
        const j = Math.floor(rng()*(i+1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
    } while(!isSolvable(arr, SIZE));
    return arr;
  }

  // Alt shuffle: valide zetten vanaf de oplossing
  // Zegt hoeveel mix-stappen we doen per bordgrootte
  function defaultScrambleSteps(size){
    const n = size*size;
    if(size <= 3) return 30;
    if(size === 4) return 120;
    return Math.min(600, n * 12);
  }
  // Schudt het bord door echte zetten vanaf de oplossing te doen
  function scrambleByMoves(steps, rng){
    const arr = GOAL.slice();
    let empty = arr.indexOf(0);
    let prevEmpty = -1;
    for(let s=0; s<steps; s++){
      const options = neighborsOf(empty);
      const filtered = options.filter(i => i !== prevEmpty);
      const moves = filtered.length ? filtered : options;
      const pick = moves[Math.floor(rng() * moves.length)];
      [arr[pick], arr[empty]] = [arr[empty], arr[pick]];
      prevEmpty = empty;
      empty = pick;
    }
    return arr;
  }

  // Checkt met inversies of een bord oplosbaar is
  function isSolvable(a, size){
    const inv = inversionCount(a);
    if(size % 2 === 1){
      // oneven breedte: inversies even
      return (inv % 2) === 0;
    } else {
      // even breedte: parity van inversies en lege-rij-vanaf-onder moet verschillen
      const emptyRowFromBottom = size - Math.floor(a.indexOf(0)/size);
      return (inv % 2) !== (emptyRowFromBottom % 2);
    }
  }
  // Telt hoeveel tegelparen omgewisseld staan
  function inversionCount(a){
    const b = a.filter(v=>v!==0);
    let inv = 0;
    for(let i=0;i<b.length;i++){
      for(let j=i+1;j<b.length;j++){
        if(b[i] > b[j]) inv++;
      }
    }
    return inv;
  }

  // Maakt de nette eindopstelling voor een bepaald formaat
  function makeGoal(size){
    const total = size * size;
    const arr = [];
    for(let i=1;i<total;i++) arr.push(i);
    arr.push(0);
    return arr;
  }

  // Past de bordgrootte aan en werkt doel en url bij
  function setSize(newSize){
    const n = Number(newSize);
    if(!Number.isInteger(n) || n < 3 || n > 8) return; // simpele guard
    SIZE = n;
    GOAL = makeGoal(SIZE);
    appendEvent('size_change', { size: SIZE });
    updateUrlParam('size', String(SIZE));
  }

  // Schrijft een waarde naar de url zonder de pagina te herladen
  function updateUrlParam(key, value){
    const url = new URL(window.location);
    if(value === null || value === undefined || value === ''){
      url.searchParams.delete(key);
    } else {
      url.searchParams.set(key, value);
    }
    history.replaceState(null, '', url.toString());
  }

  // Past de random-generator aan op basis van de ingevulde seed
  function applySeed(seedStr){
    if(seedStr && seedStr.trim()!==''){
      const trimmed = seedStr.trim();
      const s = seedFromString(trimmed);
      rng = mulberry32(s);
      updateUrlParam('seed', trimmed);
      appendEvent('seed_change', { seed: trimmed, mode: 'custom' });
    } else {
      rng = Math.random;
      updateUrlParam('seed', '');
      appendEvent('seed_change', { seed: null, mode: 'random' });
    }
  }

  // Zet alles klaar voor een nieuw spel en logt dat
  function performNewGame(trigger='manual', mode='standard'){
    currentGameMode = mode || 'standard';
    if(currentGameMode !== 'daily'){
      dailyChallengeInfo = null;
    } else if(!dailyChallengeInfo){
      dailyChallengeInfo = computeDailyChallenge();
    }
    lastWinProgression = null;
    resetStats();
    moveFX = null;
    prevEmptyIndex = null;
    hintCount = 0;
    cancelAutoHint();
    currentGameId = uuid();
    gameStartTime = Date.now();
    state = scrambleByMoves(defaultScrambleSteps(SIZE), rng);
    startState = state.slice();
    if(boardEl) boardEl.classList.remove('board-win');
    recordGameStart(currentGameMode);
    appendEvent('new_game', {
      size: SIZE,
      board: state.slice(),
      seed: seedInput ? (seedInput.value || '').trim() || null : null,
      trigger,
      mode: currentGameMode
    });
    render();
    if(shouldStartTutorial()){
      beginTutorial();
    } else if(tutorialState.active){
      clearTutorialPointer();
      tutorialState.active = false;
    }
  }

  // Start een nieuw spel met of zonder aftel-moment
  function newGame(trigger='manual', options={}){
    if(settingsOpen) closeSettings('auto');
    hideWinScreen('auto');
    const { skipCountdown = false, mode = 'standard' } = options || {};
    const launch = ()=> performNewGame(trigger, mode);
    if(skipCountdown){
      launch();
    } else {
      startCountdown(launch);
    }
  }

  // Zet het bord terug naar de startopstelling
  function resetGame(trigger='manual'){
    if(settingsOpen) closeSettings('auto');
    hideWinScreen('auto');
    clearCountdown();
    resetStats();
    moveFX = null;
    prevEmptyIndex = null;
    hintCount = 0;
    cancelAutoHint();
    currentGameId = uuid();
    gameStartTime = Date.now();
    state = startState.slice();
    if(boardEl) boardEl.classList.remove('board-win');
    appendEvent('reset_to_start', {
      size: SIZE,
      board: state.slice(),
      trigger
    });
    render();
  }

  // Zet het gekozen thema op de body en sla het op
  function setTheme(mode){
    const allowed = ['light','dark','matrix','shopify','ios'];
    if(!allowed.includes(mode)) mode = 'light';
    if(mode === 'light'){
      document.body.removeAttribute('data-theme');
    } else {
      document.body.setAttribute('data-theme', mode);
    }
    try { localStorage.setItem('theme', mode); } catch {}
    if(themeSelect) themeSelect.value = mode;
    appendEvent('theme_change', { theme: mode });
    updateUrlParam('theme', mode === 'light' ? '' : mode);
  }

  // Kiest het thema op basis van opslag of systeemvoorkeur
  function initTheme(defaultToSystem=true){
    let saved = null;
    try { saved = localStorage.getItem('theme'); } catch {}
    const allowed = ['light','dark','matrix','shopify','ios'];
    if(saved && allowed.includes(saved)){
      setTheme(saved);
      return;
    }
    if(defaultToSystem){
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
    } else {
      setTheme('light');
    }
  }
  // Alle eventlisteners voor toetsenbord, knoppen en schermveranderingen
  window.addEventListener('keydown', (e)=>{
    const key = e.key.toLowerCase();

    if(key === 'escape'){
      if(settingsOpen){
        e.preventDefault();
        closeSettings('escape');
        return;
      }
      if(isWinVisible()){
        e.preventDefault();
        hideWinScreen('escape');
        return;
      }
      if(isIntroVisible()){
        e.preventDefault();
        hideIntroScreen('escape');
        newGame('escape', { skipCountdown: false });
        return;
      }
      e.preventDefault();
      toggleSettings('escape');
      return;
    }

    if(isIntroVisible()){
      if(key === 'enter' || key === ' '){
        e.preventDefault();
        hideIntroScreen('enter');
        newGame('intro', { skipCountdown: false });
      }
      return;
    }

    if(key === 'h'){
      e.preventDefault();
      performCoachHint('keyboard');
      return;
    }

    if(isInteractionLocked()) return;

    const empty = state.indexOf(0);
    const {r,c} = indexToRC(empty);
    let target = null;
    if(key==='arrowup' || key==='w')   target = (r < SIZE-1) ? rcToIndex(r+1,c) : null;
    if(key==='arrowdown' || key==='s') target = (r > 0)      ? rcToIndex(r-1,c) : null;
    if(key==='arrowleft' || key==='a') target = (c < SIZE-1) ? rcToIndex(r,c+1) : null;
    if(key==='arrowright'|| key==='d') target = (c > 0)      ? rcToIndex(r,c-1) : null;
    if(target!==null){
      e.preventDefault();
      tryMove(target);
    }
  });
  // Koppelingen voor knoppen en selecties in de interface
  newGameBtn.addEventListener('click', ()=> newGame('button'));
  resetBtn.addEventListener('click', ()=> resetGame('button'));
  if(themeSelect){
    themeSelect.addEventListener('change', ()=>{
      setTheme(themeSelect.value);
    });
  }
  sizeSelect.addEventListener('change', ()=>{
    setSize(sizeSelect.value);
    newGame('size_change');
  });
  applySeedBtn.addEventListener('click', ()=>{
    applySeed(seedInput.value);
    newGame('seed_change');
  });
  if(hintBtn){
    hintBtn.addEventListener('click', ()=>{
      performCoachHint('button');
    });
  }
  if(copyLinkBtn){
    copyLinkBtn.addEventListener('click', async ()=>{
      const btn = copyLinkBtn;
      const url = window.location.href;
      const sharePath = window.location.pathname + window.location.search;
      let ok = false;
      try {
        if(navigator.clipboard && navigator.clipboard.writeText){
          await navigator.clipboard.writeText(url);
          ok = true;
        }
      } catch {}
      if(!ok){
        try {
          const ta = document.createElement('textarea');
          ta.value = url;
          ta.setAttribute('readonly','');
          ta.style.position = 'absolute';
          ta.style.left = '-9999px';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
          ok = true;
        } catch {}
      }
      appendEvent('share_link', { success: ok, path: sharePath });
      const prev = btn.textContent;
      btn.textContent = ok ? 'Gekopieerd!' : 'Mislukt';
      btn.disabled = true;
      setTimeout(()=>{ btn.textContent = prev; btn.disabled = false; }, 1200);
    });
  }

  if(menuToggleBtn){
    menuToggleBtn.addEventListener('click', ()=>{
      toggleSettings('button');
    });
  }

  if(closeSettingsBtn){
    closeSettingsBtn.addEventListener('click', ()=>{
      closeSettings('button');
    });
  }

  if(settingsPanel){
    settingsPanel.addEventListener('click', (event)=>{
      if(event.target === settingsPanel){
        closeSettings('backdrop');
      }
    });
  }

  if(showCoachBtn){
    showCoachBtn.addEventListener('click', ()=>{
      setCoachVisible(!coachVisible);
    });
  }

  if(showGuideBtn){
    showGuideBtn.addEventListener('click', ()=>{
      startInteractiveGuide();
    });
  }

  if(introStartBtn){
    introStartBtn.addEventListener('click', ()=>{
      hideIntroScreen('start_button');
      newGame('intro', { skipCountdown: false });
    });
  }

  if(winCloseBtn){
    winCloseBtn.addEventListener('click', ()=>{
      hideWinScreen('button');
      newGame('win_retry', { skipCountdown: false });
    });
  }

  if(nextChallengeBtn){
    nextChallengeBtn.addEventListener('click', ()=>{
      const nextSize = nextCampaignSize();
      setSize(nextSize);
      if(sizeSelect) sizeSelect.value = String(nextSize);
      hideWinScreen('next_challenge');
      newGame('campaign', { skipCountdown: false });
    });
  }

  if(exportAnalyticsBtn){
    exportAnalyticsBtn.addEventListener('click', ()=>{
      appendEvent('analytics_export', { sessionCount: sessionsCache.length });
      exportAnalyticsData();
    });
  }
  if(clearAnalyticsBtn){
    clearAnalyticsBtn.addEventListener('click', ()=>{
      clearAnalyticsData();
    });
  }

  if(dailyChallengeBtn){
    dailyChallengeBtn.addEventListener('click', ()=>{
      startDailyChallenge();
    });
  }

  if(tutorialNextBtn){
    tutorialNextBtn.addEventListener('click', ()=>{
      handleTutorialCardNext();
    });
  }

  window.addEventListener('resize', ()=>{
    positionPointer();
  });
  window.addEventListener('orientationchange', ()=>{
    positionPointer();
  });

  // Inlezen van URL-parameters zodat seed/size/thema behouden blijft
  const params = new URLSearchParams(window.location.search);
  const urlSeed = params.get('seed') || '';
  const urlSize = Number(params.get('size')) || 4;
  const urlTheme = (params.get('theme') || '').toLowerCase();
  if(urlSize){ setSize(urlSize); }
  if(sizeSelect) sizeSelect.value = String(SIZE);
  if(urlSeed){ seedInput.value = urlSeed; applySeed(urlSeed); }
  if(urlTheme){
    setTheme(urlTheme);
  } else {
    initTheme();
  }

  // Start services zoals analytics en geluid en toon het juiste startscherm
  startAnalyticsSession();
  initSoundControls();

  if(introScreen){
    showIntroScreen();
  } else {
    newGame('auto', { skipCountdown: true });
  }
})();
  // Kiest het juiste pijltje op basis van de positie van twee tegels
  function computeDirectionIcon(fromRect, toRect){
    const dy = toRect.top - fromRect.top;
    const dx = toRect.left - fromRect.left;
    if(Math.abs(dx) > Math.abs(dy)){
      return dx > 0 ? '→' : '←';
    }
    return dy > 0 ? '↓' : '↑';
  }

  // Berekent een punt halverwege de rand tussen twee tegels
  function midpointOnEdge(fromRect, toRect){
    const fromCenter = {
      x: fromRect.left + fromRect.width / 2,
      y: fromRect.top + fromRect.height / 2
    };
    const toCenter = {
      x: toRect.left + toRect.width / 2,
      y: toRect.top + toRect.height / 2
    };
    const dx = toCenter.x - fromCenter.x;
    const dy = toCenter.y - fromCenter.y;
    if(Math.abs(dx) > Math.abs(dy)){
      const sign = dx > 0 ? 1 : -1;
      return {
        x: fromCenter.x + sign * fromRect.width / 2,
        y: fromCenter.y
      };
    }
    const sign = dy > 0 ? 1 : -1;
    return {
      x: fromCenter.x,
      y: fromCenter.y + sign * fromRect.height / 2
    };
  }
