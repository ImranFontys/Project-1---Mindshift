## 2025-09-24 — Duidelijke Comments & Hint zonder Auto-Move

- **Code uitgelegd**: Alle HTML-, CSS- en JavaScript-bestanden kregen uitgebreide Nederlandse comments zodat opdrachtgevers en docenten direct snappen wat elk blok doet.
- **Hint blijft handmatig**: De hintknop toont nog steeds uitleg en een pijl, maar voert geen automatische zetten meer uit; spelers houden zelf de controle en analytics loggen geen autoTiles meer.

## 2025-09-23 — Tutorial Pointer & Guide Refresh

- **Pijl in uitleg**: De interactieve gids gebruikt nu een echte pijl (met punt) naar de juiste tegel, waardoor het duidelijker is waar je moet klikken.
- **Stap-tekst vereenvoudigd**: Elk tutor-stapje vertelt nu in één zin wat je moet doen en welke richting de tegel schuift (bijv. “tik op tegel 3, hij schuift naar rechts”).
- **Startprompt**: De eerste aanwijzing zegt expliciet dat je met die tegel het spel start, zodat beginners meteen weten wat er gebeurt.

## 2025-09-17 — Coach Walkthrough & Multi-Step Hints

- **Interactie-hints**: Coach berekent nu een pad naar de oplossing en speelt automatisch de eerste 2–3 zetten af (3×3–5×5), met pauzes zodat spelers de animatie volgen. Hintknop wordt tijdelijk uitgeschakeld en handmatige zetten stoppen de walkthrough.
- **Toegankelijke uitleg**: Coach-tekst gebruikt herkenbare posities (“hoek linksboven”, “linkerkant”) en licht toe waarom een schuif nodig is; hint-arrow blijft langer zichtbaar.
- **Coach-gids**: “Toon uitleg” start een interactieve tour met dezelfde hintplanning; de gids past zich aan en laat geen zet zien als het bord al (bijna) klaar is.
- **UI-polish**: Hintknop geeft een busy-state tijdens auto-hints en de tutorialfunctie gebruikt dezelfde padlogica voor consistente aanwijzingen.

## 2025-09-16 — Coach, Audio & Analytics Upgrade

- **Coach overlay**: hints geven nu eenvoudige, stap-voor-stap uitleg (met rij/kolomwoorden) en leggen uit waarom een zet helpt.
- **Exacte hints**: IDA*-solver met verbeterde heuristiek zorgt ervoor dat 4×4 puzzels volledig opgelost kunnen worden via de hintknop.
- **Audio & SFX**: Web Audio toegevoegd met swipe-swoosh, aparte hint/win/error geluiden en een sound-toggle in de toolbar.
- **Motion trail**: hints tonen een kort glow-spoor i.p.v. blur zodat cijfers scherp blijven.
- **iOS 26-thema**: nieuw glasachtig thema voor UI, knoppen en bord (inclusief aangepaste sound-toggle).
- **Analytics systeem**: events voor sessies, games, hints, zetten, thema/seed-wijzigingen, exports en resets worden in `localStorage` gelogd; export- en wis-knoppen toegevoegd.
- **Toolbar logo**: MindShift-logo naast de titel geplaatst en zichtbaarheid verbeterd (grotere box, thematische glow).

## Changelog (eerder) – Simpel Uitgelegd

Wat is er nieuw?
- Hint: Eén‑klik hint (H) toont de beste volgende zet op basis van Manhattan‑heuristiek (greedy). Subtiele highlight op de tegel.
- Toolbar compact: Titel + primaire acties; Instellingen inklapbaar. Kopieer‑link knop toegevoegd.
- Shuffle is altijd oplosbaar: i.p.v. willekeurige permutatie schudden we nu door een reeks geldige zetten vanaf de oplossing (seeded). Hierdoor zijn states gegarandeerd oplosbaar én reproduceerbaar.
- Thema kiezen: Je kunt nu kiezen tussen Light, Dark, Matrix en Shopify.
  - Hoe: Gebruik het dropdown menu “Thema” bovenaan.
  - Het gekozen thema wordt onthouden (localStorage) en je kunt het delen via de URL (bijv. ?theme=matrix).

- Matrix‑thema: Ziet er futuristisch uit en heeft effecten bij het bewegen van een tegel.
  - Look: Neon‑groen, monospace letters, subtiele “code‑regen” op de achtergrond.
  - Beweging: Tegels schuiven vloeiend (soepelere animatie).
  - Pulse: Eén felle, ronde gloed (glow) die kort uitzet vanaf de verplaatste tegel.
  - Aardbeving: Korte trilling van het bord, en tegels trillen iets (minder naarmate ze verder weg staan).
  - Scramble: Cijfer van de verplaatste tegel “flickert” heel kort in Matrix‑stijl en wordt dan normaal.
  - Toegankelijk: Animaties gaan uit als je ‘reduced motion’ aan hebt staan in het OS.

- Greenify‑thema: Rustige, nette stijl (Shopify‑achtig).
  - Zachte kleuren, ronde hoeken en lichte schaduwen.

- Delen en opslaan
  - Je instellingen blijven bewaard (thema, grootte, seed).
  - Je kunt een link delen met parameters, bijv.:
    - ?theme=matrix
    - ?size=4
    - ?seed=MijnSeed

Waar staat de code?
- mindshift/index.html — Thema‑selector in de knoppenbalk.
- mindshift/src/app.js — Logica voor thema’s, animatie‑triggers (pulse/quake/scramble).
- mindshift/src/styles.css — Kleuren en animaties voor Matrix/Shopify.

Tips voor testen
- Zet thema op “Matrix”. Beweeg een tegel (klik of met pijltjes/WASD) en kijk naar de pulse/quake.
- Probeer ook “Greenify” om de andere stijl te zien.
- Deel een link zoals: index.html?theme=matrix&size=4
 - Gebruik “Hint” of druk op H: de voorgestelde tegel licht kort op.

Bekend punt (voor later)
- Fixed: burenlogica werkt nu voor alle groottes (3–8). 
